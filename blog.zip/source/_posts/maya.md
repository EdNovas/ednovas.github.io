---
title: Maya 一个简洁小巧的快速启动工具
tags: [maya,windows,桌面,快速启动,效率,简洁]
id: '1186'
categories:
  - - 软件
date: 2021-02-02 12:06:00
top_img: 'linear-gradient(20deg, #0062be, #925696, #cc426e, #fb0347)'
cover: https://cdn.jsdelivr.net/gh/wdm1732418365/CDN/New%20folder/Maya-Logo.png
#top: true
#highlight_shrink: true
---

> 转载自 https://blog.arae.cc/post/25830.html ， 这也是软件作者的博客地址
> GitHub项目地址 https://github.com/25H/Maya

## 简介

Maya是一款体积小巧、简单易用的快速启动工具。不要看体积小巧，它的功能还是非常多样化的，比如：多文件拖拽添加启动、快捷键呼出、自动多列显示、lnk文件解析等等。软件没有繁杂的功能，操作中也不会产生任何垃圾文件，绿色无污染，只专注于文件的快速启动，是用户提升Windows操作体验的好帮手。

## 下载地址

GitHub下载地址：https://github.com/25H/Maya/releases
蓝奏云下载地址：https://wwa.lanzoux.com/b0bqwqjvg

## 功能
·多文件拖拽添加启动
·快捷键呼出
·快捷键运行项目
·列表滚轮滚动
·自动多列显示
·快捷方式编辑
·lnk、url文件解析
·参数变量、环境变量
·开机启动
·分类
·排序
·跨分组拖拽项目
·自定布局
·自定主题
·自定义缩放
·运行

## 特色

1、简单，恰到好处
不需要过多的思考，不需要过多的学习，上手便能熟练使用，一试便知，你一定会喜欢上它。

2、功能，短小精悍
麻雀虽小却五脏俱全，Maya苗条的身材下隐藏着巨大的能量。无限的潜能，期待你的发掘。

3、外观，精妙绝伦
简约而不简单，每一处细节均精心打磨，每一处体验都深入人心，每一步操作皆无比轻松。

4、惬意，发自内心
如春风，如夏雨，如秋叶，如冬雪。心旷神怡，妙不可言。这种感觉，绝无仅有。

5、效果，立竿见影
一分钟，桌面回归整洁。彻底摆脱图标的困扰，尽情享受属于你的桌面。

6、未来，无限可能
在通往无比强大的路上，Maya才刚刚起步，需要你的支持与鼓励，请给Maya更多的时间。

## 相关截图
最新版本界面可能与截图有出入。

![](https://i.loli.net/2020/11/01/e8gfB9G1X4NQOKx.png)

![](https://i.loli.net/2020/11/01/fT4RmanC8EdoGX9.png)

![](https://i.loli.net/2020/11/01/HqT87pQFc51Kjan.png)

![](https://i.loli.net/2020/11/01/OEvwrgTadCzj85n.png)

![](https://i.loli.net/2020/11/01/ltVmOCFA9MNcBiU.png)

![](https://i.loli.net/2020/11/01/ZiKJ5F6N3HfjYUt.png)

![](https://i.loli.net/2020/11/01/ZTGszHaKSbQPxjY.png)

![](https://i.loli.net/2020/11/01/MO19vKDLpXPsc6r.png)

## 参数变量
Maya 支持 Win环境变量同时并内置 2 个 参数变量 (变量尾不含 \ ) ，涉及范围：目录、起始位置、启动参数。

|变量名|说明|支持版本|
|:----|:----|:----|
|%mp%|所在目录|1.0.2+|
|%mr%|所在盘根目录|1.0.2+|

## 搜索命令
|命令头    |  说明          |                      支持版本|
|:----|:----|:----|
|[>]        |   执行终端命令，如：>ping arae.cc   |  1.0.5+|
|[<]       |    调用运行，如：<c:/ 打开c盘     |     1.1.4+|
|[s ]      |    可用搜索列表              |         1.1.4+|
|[bd ]     |    通过 百度 搜索        |             1.1.4+|
|[b ]      |    通过 必应 搜索          |          1.1.4+|
|[g ]     |     通过 谷歌 搜索         |            1.1.4+|
|[d ]      |    通过 DuckDuckGo 搜索    |           1.1.4+|
ps：主窗口显示后，直接输入即可，无需手动打开搜索页。