---
title: 返璞归真系列测评第三期：永远的乔布斯，从iPad 1代到乔布斯
tags: []
id: '266'
categories:
  - - 测评
date: 2020-12-07 13:03:33
top_img: 'linear-gradient(20deg, #0062be, #925696, #cc426e, #fb0347)'
cover: https://cdn.jsdelivr.net/gh/wdm1732418365/CDN/New%20folder/heybox/ipad1/technology-1607305061351-1487.webp
---

## 引言

**三个苹果改变了世界。第一个诱惑了夏娃，第二个砸醒了牛顿，第三个掌握在史蒂夫·乔布斯的手里。**

**Three Apples changed the world.The first one seduced Eve.The second one awakened Newton. The third one was in the hands of Steve Jobs.** 

## 写在最前

有那么多大神测评了那么多强大的最新科技，那么我何尝不尝试返璞归真，带大家回到智能时代的最初那几年呢。（文章内容仅代表个人观点，一切请以实际为准）

那么今天带大家测评的是

当当当当！苹果的！

![](https://cdn.max-c.com/heybox/dailynews/img/16bc6c19eabf58d7172c2bddc2fe7a99.jpg)

https://wallup.net/technology-apples-apple-inc-colorful/

## iPad 1代！

这回我终于有好好拍照了！（可能真的有好好拍吧。。。）话不多说，先来上几张外观图

![](https://cdn.max-c.com/heybox/dailynews/img/f19bef7f8881102786d89d0efcbe578a.jpg)

![](https://cdn.max-c.com/heybox/dailynews/img/7fd7fbdd10dd85c123853ed9332cc3f1.jpg)

![](https://cdn.max-c.com/heybox/dailynews/img/65823a4f8c4672ffbd9cd73abef2a34b.jpg)

那么如上所示，作者这里的这个呢是当年iPad 1代刚刚在中国大陆开卖第二天就买的一台 iPad Wi-Fi 版 64G 的机子，据查价格可能是RMB 5,288，也有可能偏高。我也忘了具体购买日期是哪天了，但查阅了下资料，应该是在2010年9月18日买的（国内开卖后第二天）。使用时长至少有个小5、6年了，所以会有很明显的刮痕。

## 简介

很多hxd在我写 iPhone 4s 的时候就说 4s 是乔帮主的最后一作，但是我却没有用乔帮主的经典系统，我也甚是惭愧啊。所以在这期我就把这个老家伙掏出来了，iOS 5.1.1的系统（无法再升级了）！这可是绝对的经典乔布斯时代一成不变的经典系统了。实际上从iPhone OS 1（那时候还不叫 iOS，从 iOS 4 开始改为 iOS）开始一直到 iOS 6 都没有太大的改变，一直继承上一代的经典的UI界面。那么我们来看几张图来找回那个熟悉的感觉吧！

如下是解锁画面（日期出了点问题，没有同步，我也没去设置）

![](https://cdn.max-c.com/heybox/dailynews/img/563d64f20a366a8147170a96fc561044.png)

如下是iOS 5.1.1的系统桌面

![](https://cdn.max-c.com/heybox/dailynews/img/15c3d06c558196d5a42f1921fcaa5d9d.png)

如下是文件夹的效果，啊这波经典怀旧直接回忆杀了有木有！，还能看到那经典的 Game Center！

![](https://cdn.max-c.com/heybox/dailynews/img/c9498a212489b617c1bf3f1fd40b6d62.png)

我认为设计更加合理的多任务管理器

![](https://cdn.max-c.com/heybox/dailynews/img/f3093c32b2d90e8804589f7ebc90f09b.png)

经典的设置界面以及输入法

![](https://cdn.max-c.com/heybox/dailynews/img/2189d232e52a13da4b9ff14b9114f923.png)

## 配置

**发布日期**             Wi-Fi机种：2010年4月3日         Wi-Fi+3G机种：2010年4月30日

**操作系统**             iOS 3.2 (2010年4月3日)    iOS 5.1.1 (2012年5月7日)

**尺寸**                    9.56英寸 x 7.47英寸 x 0.5英寸（24.3 cm x 19.0 cm x 1.3 cm）

**重量**                  Wi-Fi版：1.5磅（680g）  WiFi+3G版：1.6磅（730g）

**电源**                内置不可拆卸的可充电锂离子聚合物电池 3.75V\*6600mAh, 随机AC/DC适配器输出5.1V\*2.1A

**中央处理器**      1 GHz Apple A4

**内存**                  256MB DDR RAM

**存储空间**        16G、32G、64G

**屏幕**                  1024 x768，9.7英寸（25cm），132ppi，3：4长宽比，LCD显示器

**相机**                  无

**Wi-Fi**                802.11a/b/g/n（3G机种另加micro-SIM插槽）

**蓝牙**                  Bluetooth 2.1

（某基百科，“iPad（第一代）”n.d.）

## 亮点一：大小（厚度）

这个24.3 cm x 19.0 cm x 1.3 cm的尺寸我一点不觉得大或者是厚重，反而我认为这才是一个平板电脑应该有的大小，而对于680g的质量来说的话，确实挺难想象当年一个智能平板的重量会有这么厚实，但是要知道2020新款苹果iPad10.2英寸也有490克的重量。所以实话实话，这点重量差距并不算大。同时也很难想象一个10年前的铁家伙能这么轻（当时感觉应该可能会是个大铁家伙）。至于尺寸大小的话，我反而觉得这个尺寸是正正好好，现在的iPad宽度会略窄一些，反而不好看了。至于他的高度，可是**比一枚硬币还薄**！

![](https://cdn.max-c.com/heybox/dailynews/img/556427da13d318ae38f97aea196a2551.jpg)

这简直让我震惊了！十年前的产品就能做到比一枚一元硬币还要轻薄！简直不敢想象！错了，重来。

![](https://cdn.max-c.com/heybox/dailynews/img/a6dc0e15c4701fc7337ba224102a353a.jpg)

那么可以看到他是大概7枚硬币的高度，这也主要是以为他庞大的后盖。如下图可见，中间突出的一块后盖。但是这样不也显得更厚实吗，笑

![](https://cdn.max-c.com/heybox/dailynews/img/2009a78810020698e427784ff74c69df.jpg)

**返璞归真：**在现在看来的话，这个尺寸和重量依旧是一个差不多的水平，可以说iPad一代简直就是智能平板的鼻祖了，几十年来都没有怎么变化过的外观设计就足以证明这一点了。在现如今也只会觉得这个比较厚实，但却不会觉得非常的沉重，也有可能是和我天天锻炼有关？嘿嘿嘿

**话说当年：**2010年我们家连个智能手机都没有的时候，那时候这个玩意买回来可简直成了宝贝了，从来没有见过这么智能的能用手操控的还能有如此便携性的机器！当时就感觉到了这个东西在未来的无限潜力，谁能想到现在成了买前生产力，买后爱奇艺的工具呢（我没有针对任何人哦）

## **亮点二：电池**

这个大铁家伙啊，电池简直bt一般，给你们看看某思助手的电池数据就能知道了。如图所示，充电了952次，电池寿命依旧还有81%，而且这可是整十年过去了！还能有5240mAh的实际容量。

![](https://cdn.max-c.com/heybox/dailynews/img/0486116c8da53b8be8f92a9c5ab6e777.png)

**返璞归真：**现在充满电量也用不了多，大概也就花了不到半天的时间，也与我用的已经坏的不能再坏的iPad一代原装充电线有关吧，估计都会漏电了，用绝缘胶带缠了一圈又一圈。看来这个充电线的问题是苹果祖传的啊。至于续航的话，使用个2、3天成天看视频啥的也不成问题，甚至更久（几年前iOS5.1.1还算是主流系统的时候）。真的很难想象这个大家伙在使用了这么久以后，电池没有出现过任何问题，比如低于5格点掉电飞快等情况，真的是实打实的稳定。

**话说当年：**当时这台机器还在年轻气盛的全胜时期，正常使用个近4、5天都没啥问题，天天看视频、小说、网页不亦说乎，当时真的打开个地图软件都能晚上一整天

## 亮点三：流畅的使用

可能他最强的莫过于流畅的系统了吧，这么多年过去了，他依旧可以很流畅，没有任何的卡顿。打开个qq，速度一点也不逊于之前测评的iPhone 4s，甚至**有过之而无不及。**当然也与受限于系统和硬件，无法运行需求更高的软件有关，但仍然很难想象系统的优化是做的多么好。

**返璞归真：**现在的话，某奇艺是可以安装旧版本，但是已经无法连接了。

![](https://cdn.max-c.com/heybox/dailynews/img/e3891f7839bc5d89b444e483f156a026.png)

至于老版本的QQ HD，依旧可以正常使用，甚至还能使用语音电话

![](https://cdn.max-c.com/heybox/dailynews/img/f5950685e628153cf63644c09cd951e4.png)

![](https://cdn.max-c.com/heybox/dailynews/img/da43e8873eeb04a26f36b8afdd5e8c4f.png)

![](https://cdn.max-c.com/heybox/dailynews/img/20d2a8ccd8ebc41d18cd303bae80be5f.png)

网页浏览以及加载相比iPhone 4s之下会慢不少，但也尚可接受

![](https://cdn.max-c.com/heybox/dailynews/img/bf81256b49a9efe8839e5f978500aa05.png)

![](https://cdn.max-c.com/heybox/dailynews/img/299bc6655c65696a0e09ac4b79ff10c1.png)

**话说当年：**当时更可谓是”打遍天下无敌手了“（有点夸张了哈哈），但不得不承认当时的速度可是刷新了我的认知，很难想象在那个机箱都老大的年代，能有机器把那些都浓缩成这么一个小小的铁块，还能保持和电脑差不多的速度和效果（仅指浏览器等方面，不代表机器硬件性能）

## 缺点

对于这么一个有意义的产品，我个人认为他不应该有缺点，它更多代表的是一个开创性的思维，一个新产品的建立。而且我相信几个明显的缺点大家稍微想想也就能心知肚明了。

## 意义

苹果公司在2010年1月27日于美国旧金山欧巴布也那艺术中心所举行的发表会上，由首席执行官史蒂夫·乔布斯亲自发布。（某基百科，”iPad（第一代）“，n.d.）

当时的iPad在2010年4月3日开始在美国发售，发售28天销售量就已经突破了100万部，销售速度简直比iPhone还要快。在同年6月22日苹果公司再次发表声明，iPad开售八十日已经售出三百万部。要知道当时仅仅是在国外部分地区首发，国内一直到10月才发售。根据环球网的报道，截止至2013年10月23日，苹果在美国旧金山芳草地艺术中心召开新品发布会，宣布旗下iPad平板电脑系列产品的总销量已超过1亿7000万台，在全球平板电脑市场中的占有率达81%。（陈健，环球网，”iPad总销量达1亿7000万台 市场占有率达81%“，2013.10.23）对于当年还仅仅是智能时代的初始阶段来说，这是一个多么恐怖的数字。

不敢说他是具有划时代意义的一个作品，但可以说他不仅仅是一个智能设备，他更加是个艺术品，是一个创新性的思维，使得苹果即使到如今也依然是智能平板的标杆。

## 史蒂夫·乔布斯

由于这可能是最后一期苹果设备测评了（主要是穷，家里买不起），所以我们也来谈谈Steve Jobs。

![](https://cdn.max-c.com/heybox/dailynews/img/1a4d9545ce53293fd1b9263842b5ca66.jpg)

https://www.aasaanhai.net/wp-content/uploads/2017/07/steve-jobs-biography-in-hindi.jpg

史蒂夫·乔布斯生于1955年2月24日。最早期他与斯蒂夫沃兹尼亚克一起在自家小车库里琢磨电脑，想要造出一台能够家用的电脑（当时电脑全都是商用，体积大，价格贵），随后”苹果Ⅰ号“被制造了出来，公司名定为”苹果“。

![](https://cdn.max-c.com/heybox/dailynews/img/929cd8afd58d7e6a8a4d352ad4963bdf.jpg)

https://techcrunch.com/wp-content/uploads/2017/04/apple1working.jpg?resize=768

1977年4月，在计算机展览会展示了苹果Ⅱ号样机。1980年12月12日，苹果公司股票公开上市，在不到一个小时内，460万股全被抢购一空。后来乔布斯与管理人员观念不同，同时IBM也推出个人电脑，抢占市场，于是董事会撤销了乔布斯的经营大权，后者也与1985年9月17日离开了自己亲手创办的公司。

![](https://cdn.max-c.com/heybox/dailynews/img/6ce1c459fa4e685ddb49ee45c1da4995.jpg)

https://steemitimages.com/DQmcTCGT4DMq6RLbDRWHkegGsagSxfmNH4fPeaAd6DFgpFG/image.png

在他的独立时期，成立了NeXT公司以及皮克斯动画工作室，后者现在成为了世界顶尖动画制作室。工作室于2006年被迪士尼收购，乔布斯也成为迪士尼最大个人股东。

![](https://cdn.max-c.com/heybox/dailynews/img/03869587837e512647d2479a198a53c7.jpg)

https://wallpaperlayer.com/img/2015/8/pixar-logo-wallpaper-3020-3216-hd-wallpapers.jpg

在1996年苹果公司陷入困境的时候，他还是毅然决然的回到苹果并实施一系列改革，开始研发iMac和OS X操作系统。1997年苹果推出iMac，以及MAC OS X操作系统。2000年推出iTunes和iPod，并开设专卖店。2007年6月29日，推出iPhone 1代，使用iPhone OS操作系统，随后发布了iPhone 3G和3GS。2010年6月8日，发布iPhone 4。

![](https://cdn.max-c.com/heybox/dailynews/img/1202149d4b6d66690c4b8af266ef4535.jpg)

https://image.businessinsider.com/5d448613100a2417523faa18?width=1136&format=jpeg

2011年8月24日，史蒂夫·乔布斯提交辞职申请，并建议蒂姆·库克接替他的职位。2011年10月6日，苹果董事会宣布前行政总裁乔布斯于当地时间10月5日因胰腺神经内分泌肿瘤逝世，终年56岁，至此，一代传奇与世长存。

![](https://cdn.max-c.com/heybox/dailynews/img/f5d5a2745ed217d58e27d0a415bea3c2.jpg)

https://losko.ru/wp-content/uploads/2019/09/dzhobs\_dzen.jpg

（深沉的思考195，百度百科，”史蒂夫·乔布斯“）

在这也推荐一部电影：史蒂夫·乔布斯（Steve Jobs），电影讲述了乔布斯的真实故事，展现了乔布斯人生中的两个关键时期：1976年21岁的乔布斯与26岁的斯蒂夫·沃兹尼亚克在自家的车房里成立苹果公司，以及1985年乔布斯愤而辞去苹果公司董事长。（某基百科，”乔布斯（电影）“，n.d.）

**乔布斯为什么会成功？**主要是因为有超前的创新思维，这点从他发布的每一个产品都引领了时代的进步可以看出。从最早的家用电脑到iPod到Apple TV到MAC到iPhone再到iPad，每一个无不是经典，让普通民众也能有钱买到曾经高贵的电脑。还因为他对细节的把控，他是个完美主义者，从主板、电源、机箱、使用体验等各方面，都可以感受到他的精益求精，让苹果产品做的尽量完美无瑕。这也正是为什么时隔10多年后，他的产品依旧能够使用至今而几乎完全没有卡顿。

人无完人，正如被咬掉的苹果一样，都是有缺憾的。乔布斯也是如此，他也有些性格的偏执，但也正是这才能让他有无限的潜力从而设计出一代经典并且快速推动了时代的发展。也正如他所说的：

## Stay hungry，stay foolish

## **求知若饥，虚心若愚**

![](https://cdn.max-c.com/heybox/dailynews/img/c4bc596da0d54e967168803f777dbdb8.jpg)

https://zhuanlan.zhihu.com/p/23431074