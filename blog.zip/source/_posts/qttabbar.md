---
title: QTTabbar多窗口资源管理器——资源管理器的最优解决方案
tags: [资源管理器,效率,QTTabbar]
id: '1169'
categories:
  - - 软件
date: 2021-01-23 19:51:00
top_img: 'linear-gradient(20deg, #0062be, #925696, #cc426e, #fb0347)'
cover: https://cdn.sspai.com/2019/01/14/7ff7452557d82922876d344e077e5bc3.png?imageMogr2/auto-orient/quality/95/thumbnail/!1420x708r/gravity/Center/crop/1420x708/interlace/1
#highlight_shrink: true
---
>转载自 https://code.seniortesting.club/blog/2020/How-To-Speed-Github.html
<div data-v-c778343a="" class="content wangEditor-txt minHeight"><h1 id="ss-1-1547443243023">前言</h1>
<p>对于广大使用 Windows 系统的同学们来说，「资源管理器」一定是大家再熟悉不过的一位老伙计了，说起名字可能还会有不知道的同学，但我要是说起「文件夹」，大家的脑海里应该立刻就能浮现出熟悉的画面：一个四四方方的小盒子里，放着我们所有的文件：音乐、视频、软件……，几乎任何一个和文件打交道的操作，都一定少不了它。  </p>
<p>但就是这样一个重要的角色，却一直令效率人士诟病不已，因为从 XP 时代到如今的 Win10，微软在资源管理器上始终没有给我们带来令人满意的升级。界面不咸不淡的地改变着风格，功能却仍旧只是简单的分类、排序、重命名和查看属性；为了找一个文件，不得不点进一层又一层嵌套着的子文件夹，如果没有找到，那么就又得先返回，再点进新的文件夹里接着找；如果你要拖拽复制，就需要重新打开一个新的文件夹；如果你打开的文件夹过多，一会儿后，你就只能在满桌面的文件夹中不知所措；如果你不小心关掉了一个正在用的文件夹，还得重新从磁盘的层级开始一级级打开文件夹寻找。  </p>
<p>提升 Windows 系统的文件操作体验几乎是每一个效率人士的心声，如何才能在 Windows 系统里获得高效的文件操作体验，在少数派的文章里可以找到非常多的答案，总体上来说大致分为两类。  </p>
<h2 id="ss-2-1547443243024" class="ss-hId-1" hid="ss-hId-1">重新构建一个「资源管理器」</h2>
<p>Total Commander 和 Directory Opus 都是属于这一类，它们试图推翻现有资源管理器：<strong>既然系统自带的资源管理器如此难用，那么索性重新做一个全新的「资源管理器」</strong>，然后在这个全新的「资源管理器」里实现我们想要的增强功能，比如标签栏、文件预览等。</p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/8bde96097a9803ad911a9eb49cc42a03.png?imageView2/2/w/1120/q/90/interlace/1/ignore-error/1" alt="Directory Opus" title="Directory Opus" data-original="https://cdn.sspai.com/2019/01/14/8bde96097a9803ad911a9eb49cc42a03.png" data-index="0" class="lazyLoadEnd"><figcaption class="ss-image-caption">Directory Opus</figcaption></figure><p></p>
<p>但是遵循着这一类思路诞生的软件在我个人看来，有一个非常大的痛点，那就是无处不在的「割裂感」，以 Directory Opus 为例，我曾经用过一段时间的 Directory Opus，从安装完成并在桌面上创建了一个全新图标开始，它就无时无刻不在提醒着我，这是一个「独立的软件」，和自带的资源管理器没有任何关系，它有着完全不一样的界面，完全不一样的操作逻辑，更糟糕的是你居然可以同时使用它们，尽管 Directory Opus 提供了「替代部分资源管理器」的功能，但当你在其他软件打开文件夹或者选择文件的时候，弹出来的仍然是以前那个老旧而熟悉的「文件夹」窗口。可以想象，当你在和朋友聊天的时候，用微信发几条语音，然后又要切换到 QQ 发几个表情，这种「割裂感」在一定程度上带来的是非常糟糕的体验，因为这预示着你以后很有可能需要同时掌握两套不大相同的文件操作逻辑。  </p>
<p>另一方面，「割裂感」不仅是带给自己的，还很有可能会带给别人，当你花了不短的时间习惯了 Directory Opus 全新的操作体验，并且满心欢喜地在自己手头的所有电脑都装上 Directory Opus 时，还会面临一个新的问题，就是别人该如何使用你电脑？如果是自用的电脑倒还好，但工作用的电脑难免会需要同事来操作一二，比如在我工作的过程中，如果自己不在电脑旁又需要做一些紧急的工作时，就需要让在公司的同事帮忙进行操作，对于同事来说，在该弹出文件夹的时候弹出一个陌生的窗口，显然会很崩溃的。  </p>
<p>可能关于「割裂感」这件事我说得有一点上纲上线了，但不能否认的是它确实多多少少存在于这一类的软件中，并且给日常使用带来了一些问题，而对于大多数人来说，极其专业的文件操作体验并不是一个刚需，这个时候就可以关注第二类思路带来的产品了。  </p>
<h2 id="ss-2-1547443243024" class="ss-hId-2" hid="ss-hId-2">增强现有的「资源管理器」</h2>
<p>这一类软件的目的并<strong>不是颠覆当前的资源管理器，而是改造现有的资源管理器</strong>，提高资源管理器的可用性，试图从资源管理器本身入手，让它焕发出新的光彩。  </p>
<p>说到第二类的思路就不得不提 Windows 上「资源管理器」的本质，其实资源管理器在 Windows 中就是一款特殊的「浏览器」，它与 Windows 默认自带的 IE 浏览器如出一辙，使用的很有可能是同一套框架（未考证，仅为猜测），因为在 IE 浏览器中能够做到的事情，资源管理器也同样能做，譬如打开网页、前进、后退、刷新、搜索等，更重要的是，<strong>在资源管理器里可以加载 IE 浏览器的插件</strong>，正是这一特性，让广大的开发者有了更多想象的空间：<strong>通过插件的方式为资源管理器提供新的功能</strong>，也就是说这一类软件实际上都是 IE 浏览器插件。  </p>
<p>Clover 是我接触的第一款此类软件，当年高中时第一次得知有一款软件可以给平常使用的文件夹加上如同 Chrome 一般的多标签栏，那种激动的心情难以描述，因为这是这个世界第一次给 Windows 系统中千篇一律的资源管理器带来了一点色彩。Clover 做的事情也非常简单，将资源管理器操作与浏览器操作重新统一起来，通过多标签栏来将散落在各个地方的文件夹集中在一起，使用书签代替快捷方式来收藏自己常用的文件夹，再为资源管理器加上浏览器中常见的复制标签页、恢复标签页、历史记录等，令传统的文件操作焕然一新。  </p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/9b9e5271f0478b14c50bf97e9890e2b5.png?imageView2/2/w/1120/q/90/interlace/1/ignore-error/1" alt="Clover熟悉的界面，但后来卖身之后开始捆绑广告插件和加入新闻弹窗，逐渐从我的视野里消失了" title="Clover熟悉的界面，但后来卖身之后开始捆绑广告插件和加入新闻弹窗，逐渐从我的视野里消失了" data-original="https://cdn.sspai.com/2019/01/14/9b9e5271f0478b14c50bf97e9890e2b5.png" data-index="1" class="lazyLoadEnd"><figcaption class="ss-image-caption">Clover熟悉的界面，但后来卖身之后开始捆绑广告插件和加入新闻弹窗，逐渐从我的视野里消失了</figcaption></figure><p></p>
<p>本文将要介绍的 QTTabbar 也是同属于这第二类思路的软件，通过插件的方式注入到资源管理器当中，提供了诸如多标签栏、文件预览、群组、脚本、插件等功能。不管是 QTTabbar 还是 Clover，其核心的思想就是「增强资源管理器」，所以他们不会为使用者带来任何「与之前大相径庭的操作体验」，在你面前的仍然还是以前的那个资源管理器，但在一些细微的地方，软件为你提供了更好更便捷的操作体验，即使你是一个顽固的保守派，它们也不会干扰你通过传统方式使用资源管理器，最重要的是软件与资源管理器无缝衔接在一起，不会存在「一件事情，两种逻辑」的割裂感，从这点看来，这类软件完全抓住了我的心。  </p>
<p>总结起来，第一类软件适合于重度的文件管理者，实际上，他们需要的是一个专业的文件管理器，而不是 Windows 的资源管理器，所以他们可以围绕着一个全新的软件来建立自己全新的文件管理体系；对于第二类软件，他们适合的是普通的用户，他们的需求点在于对现有资源管理器进行适当的增强来满足自己日常的文件操作需求，而我就是这样的一个普通用户，所以在这里我就要向大家介绍这款资源管理器增强软件中的佼佼者：QTTabBar  。</p>
<p>使用 QTTabbar 可以为你带来以下的优势：</p>
<ul>
<li>与 Total Commander 和 Directory Opus 相比，你不需要学习一个全新的软件，它依托于原本的资源管理器来提供功能，原来怎么操作，现在也还怎么操作，也许 QTTabBar 提供了一些你完全适应不了新功能，你也可以忽略它们，甚至是只使用其中的一个功能。  </li>
<li>与 Total Commander 和 Directory Opus 相比，这是一个完全免费的软件，并且还在不断更新，你不需担心哪天停止付费后，长期培养下来的操作习惯就此作废，尤其是你对文件操作的效率提升的需求只是入门级别的。当然，如果你有能力并喜欢 QTTabBar 带来的体验，还是建议你对 QTTabBar 进行捐赠。  </li>
<li>与 Clover 相比，QTTabbar<br>提供了更多优秀的功能体验，多标签栏只是其中一个小的功能项，完善的功能和高度的可定制性足以满足大多数人的个性化需求。  </li>
<li>与 Clover 相比，没有令人不知所云的会员体系，没有登录和弹窗，是一个完全可以离线使用的软件。  </li>
</ul>
<p>接下来让我们看一下 QTTabbar 能给我们带来怎么样的新体验。  </p>
<h1 id="ss-1-1547443243024">启用 QTTabbar</h1>
<p>对于各位长期在少数派关注效率软件的各位，本来应该是不必要花费篇幅在软件安装上，但由于 QTTabbar 本身的特性，导致它的开启和普通的软件有一些不一样的地方，官网上也没有提供详细的步骤，所以在此简单地说一下 QTTabbar 的安装和开启。  </p>
<p><em>以下操作均在 Win10 下进行</em></p>
<h2 id="ss-2-1547443243024" class="ss-hId-3" hid="ss-hId-3">下载</h2>
<p>强烈推荐从官网上下载到最新的 QTTabbar，一来是可以体验到最新的软件功能，二来我也在网上看到看到了一些所谓的「修改版」，作为一款免费的软件，实在是没有理由从非官网的途径下载 QTTabbar。</p>
<p><strong>官网：<a href="http://qttabbar.wikidot.com/" title="QTTabBar - QuizoApps">QTTabBar - QuizoApps</a></strong></p>
<p><em>本文写于2019年1月12日，截止至目前，官网的最新版本为「ver 1309」，但这个「ver 1309」的版本只是一个补丁包，并不能直接安装，你需要先安装「ver 1308」的安装包，再安装「ver 1309」进行升级。</em></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/6b875ef79515848cacaba19830543473.jpg?imageView2/2/w/1120/q/90/interlace/1/ignore-error/1" alt="安装步骤" title="安装步骤" data-original="https://cdn.sspai.com/2019/01/14/6b875ef79515848cacaba19830543473.jpg" data-index="2" class="lazyLoadEnd"><figcaption class="ss-image-caption">安装步骤</figcaption></figure><p></p>
<h2 id="ss-2-1547443243024" class="ss-hId-4" hid="ss-hId-4">安装</h2>
<p>安装的过程不再赘述，点击下一步即可。</p>
<h2 id="ss-2-1547443243024" class="ss-hId-5" hid="ss-hId-5">启动</h2>
<p>如何开启 QTTabbar 是每一个刚开始使用 QTTabbar 的同学必然会问到的问题，安装完成的 QTTabbar 没有在系统里创建任何图标，仿佛安装完成后就消失了，试着打开一个新的文件夹似乎也没有变化，想必你也和第一次使用时的我一样懵了，接下来就让我来介绍一下如何开启 QTTabbar。</p>
<ul>
<li>新打开一个「资源管理器」，也就是随意打开一个文件夹。</li>
<li>点击顶栏的「查看」</li>
<li>点击最右边的「选项」</li>
<li>选择「QTTabBar」<br>可以看到好几个带有 QTTabbar 或 QT 字样的选项，这里就是 QTTabbar 真正的入口，不同的选项代表着 QTTabbar 不同的增强界面，在这里我们只需要选择「QTTabbar」的选项就可以立即开启 QTTabbar 提供的基础增强界面「多标签栏」（部分系统可能需要重启「资源管理器」或重新打开文件夹）</li>
<li>当看到我们的资源管理器上多出了一栏像浏览器一样的标签栏，就说明你已经开启成功了。</li>
</ul>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/a203d40420de778d27426ea2634b11d2.jpg?imageView2/2/w/1120/q/90/interlace/1/ignore-error/1" alt="开启 QTTabBar" title="开启 QTTabBar" data-original="https://cdn.sspai.com/2019/01/14/a203d40420de778d27426ea2634b11d2.jpg" data-index="3" class="lazyLoadEnd"><figcaption class="ss-image-caption">开启 QTTabBar</figcaption></figure><p></p>
<p><em>必须额外说明的一点是，如果你的电脑里有装 360 或类似的安全软件，那么你很有可能会在一件加速的时候将 QTTabBar 禁用掉，因为 QTTabBar 属于浏览器插件，会被安全软件认为是不必要开启的插件，从而禁用掉。下图将演示如何在 QTTabBar 由于各种原因被禁用后如何重新打开。</em></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/b8ff3eb5e987f017473d8d0aa38f6d93.jpg?imageView2/2/w/1120/q/90/interlace/1/ignore-error/1" alt="重新启用 QTTabBar" title="重新启用 QTTabBar" data-original="https://cdn.sspai.com/2019/01/14/b8ff3eb5e987f017473d8d0aa38f6d93.jpg" data-index="4" class="lazyLoadEnd"><figcaption class="ss-image-caption">重新启用 QTTabBar</figcaption></figure><p></p>
<h2 id="ss-2-1547443243024" class="ss-hId-6" hid="ss-hId-6">基础使用</h2>
<h3 id="ss-3-1547443243024" class="ss-hIdChildren-1">切换语言</h3>
<p>对于我们来说，使用软件的第一步是先将语言切换到熟悉的中文， QTTabBar 默认并不提供中文，QTTabBar 的多语言支持是通过加载语言文件的方式实现的。切换语言的步骤如下：</p>
<ul>
<li>鼠标右击标签栏；</li>
<li>点击「QTTabBar Options…」打开 QTTabBar 的设置页面；</li>
<li>在「常规选项」的界面中找到「Language」一栏；</li>
<li>点击「Download language file…」按钮，然后会弹出语言下载页面，这里有全世界热心网友们制作的各个语言的语言文件，光是中文就不止一个，在这里我推荐的中文语言文件是「吃爆米花的小熊」制作的这一份简体中文语言文件；</li>
<li>下载到电脑，然后在 Language 处选择刚刚下载好的语言文件，点击确定后就能成功切换到中文了；</li>
<li>最后一步是你需要把所有的文件夹关闭，再重新打开新的文件夹的时候你就可以看到 QTTabBar 相关的界面都变成中文了。</li>
</ul>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/5f42efbddff695b6242a46c02b2918b3.jpg?imageView2/2/w/1120/q/90/interlace/1/ignore-error/1" alt="切换语言" title="切换语言" data-original="https://cdn.sspai.com/2019/01/14/5f42efbddff695b6242a46c02b2918b3.jpg" data-index="5" class="lazyLoadEnd"><figcaption class="ss-image-caption">切换语言</figcaption></figure><p></p>
<p><em>如果你发现当前的语言仍然没有切换成功，可以尝试在任务管理器中强制重启资源管理器。</em></p>
<h3 id="ss-3-1547443243025" class="ss-hIdChildren-2">多标签栏</h3>
<p>对于任何一个增强版的「资源管理器」，多标签栏一定是必不可少的，这种源自于浏览器的操作方式，把原本各自独立的单个文件夹集中在一个窗口里，每一个标签都表示一个文件夹，让打开过的文件夹一目了然，更易于管理，同时 QTTabbar 也为多标签栏附带了许多浏览器式的操作，下面列举了其中常用的几个操作。</p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/9ca7e2e7f67d00944381e6bb9b2a7d6b.gif" alt="关闭标签" title="关闭标签" data-original="https://cdn.sspai.com/2019/01/14/9ca7e2e7f67d00944381e6bb9b2a7d6b.gif" data-index="6" class="lazyLoadEnd"><figcaption class="ss-image-caption">关闭标签</figcaption></figure><p></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/100f00defbffddbea9f15a710292140a.jpg?imageView2/2/w/1120/q/90/interlace/1/ignore-error/1" alt="克隆标签" title="克隆标签" data-original="https://cdn.sspai.com/2019/01/14/100f00defbffddbea9f15a710292140a.jpg" data-index="7" class="lazyLoadEnd"><figcaption class="ss-image-caption">克隆标签</figcaption></figure><p></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/7a2030ff1911105d1a172f798ecda1fe.jpg?imageView2/2/w/1120/q/90/interlace/1/ignore-error/1" alt="切换标签" title="切换标签" data-original="https://cdn.sspai.com/2019/01/14/7a2030ff1911105d1a172f798ecda1fe.jpg" data-index="8" class="lazyLoadEnd"><figcaption class="ss-image-caption">切换标签</figcaption></figure><p></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/f3dea507ce0bb9897790c0faf2dae743.jpg?imageView2/2/w/1120/q/90/interlace/1/ignore-error/1" alt="鼠标滚轮切换标签" title="鼠标滚轮切换标签" data-original="https://cdn.sspai.com/2019/01/14/f3dea507ce0bb9897790c0faf2dae743.jpg" data-index="9" class="lazyLoadEnd"><figcaption class="ss-image-caption">鼠标滚轮切换标签</figcaption></figure><p></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/c48817700a106fecf0caf1a152aed788.jpg?imageView2/2/w/1120/q/90/interlace/1/ignore-error/1" alt="鼠标拖动合并与分离标签" title="鼠标拖动合并与分离标签" data-original="https://cdn.sspai.com/2019/01/14/c48817700a106fecf0caf1a152aed788.jpg" data-index="10" class="lazyLoadEnd"><figcaption class="ss-image-caption">鼠标拖动合并与分离标签</figcaption></figure><p></p>
<h3 id="ss-3-1547443243025" class="ss-hIdChildren-3">群组</h3>
<p>作为一个浏览器，怎么可以没有书签呢？书签可以帮助我们记录下常用文件夹，对这些文件夹进行分类，在需要的时候可以一键直达，不过在 QTTabBar 里面这个我们熟悉的书签栏被称为「群组」，意为将我们收藏的文件夹进行分组，不过事实上不管是操作还是理念都和我们在浏览器中使用的书签完全相同，并且 QTTabBar 还提供了桌面插件，帮助我们在任何时候都能快速打开我们的群组列表。</p>
<p> QTTabBar 收藏的群组不仅仅是我们指定的那个文件夹，在群组栏里还可以直接预览该文件夹下的子文件和子文件夹，并且一键直达我们想要打开的任何一个文件或文件夹。</p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/8439e0f86c329d0b7e43c0c9c12d8420.jpg?imageView2/2/w/1120/q/90/interlace/1/ignore-error/1" alt="创建新群组并添加当前标签到该群组，随后就可以快速访问该群组中的内容并打开" title="创建新群组并添加当前标签到该群组，随后就可以快速访问该群组中的内容并打开" data-original="https://cdn.sspai.com/2019/01/14/8439e0f86c329d0b7e43c0c9c12d8420.jpg" data-index="11" class="lazyLoadEnd"><figcaption class="ss-image-caption">创建新群组并添加当前标签到该群组，随后就可以快速访问该群组中的内容并打开</figcaption></figure><p></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/10d3a3882996bbb8c3a689734379ccfb.jpg?imageView2/2/w/1120/q/90/interlace/1/ignore-error/1" alt="双击桌面或任务栏快速打开群组列表，快速预览文件并打开" title="双击桌面或任务栏快速打开群组列表，快速预览文件并打开" data-original="https://cdn.sspai.com/2019/01/14/10d3a3882996bbb8c3a689734379ccfb.jpg" data-index="12" class="lazyLoadEnd"><figcaption class="ss-image-caption">双击桌面或任务栏快速打开群组列表，快速预览文件并打开</figcaption></figure><p></p>
<h3 id="ss-3-1547443243025" class="ss-hIdChildren-4">文件预览</h3>
<p>很多人都羡慕 macOS 的方便快捷预览文件内容的功能，Windows 上也有很多软件补充了这一个功能，QTTabBar 也不会缺席，在 QTTabBar 中，我们也同样可以做到在不打开文件的情况下对常用文件格式进行预览，我们可以在 QTTabBar 设置里的「文件预览」打开文件自动预览，还可以设置「仅在按住 shift 键时才进行预览」，当然我会推荐你使用按住 shift 键预览，毕竟预览文件，尤其是预览视频文件的时候会消耗一定的系统资源，频繁预览可能会对性能差的机器造成卡顿，所以大家要根据自己电脑的实际情况量力而行。</p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/5e520b1f4390bac872bd97a46dfd2f72.jpg?imageView2/2/w/1120/q/40/interlace/1/ignore-error/1" alt="图片文件预览" title="图片文件预览" data-original="https://cdn.sspai.com/2019/01/14/5e520b1f4390bac872bd97a46dfd2f72.jpg" data-index="13"><figcaption class="ss-image-caption">图片文件预览</figcaption></figure><p></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/0e9ec29fe5066ede4eda17321c291327.jpg?imageView2/2/w/1120/q/40/interlace/1/ignore-error/1" alt="文本文件预览" title="文本文件预览" data-original="https://cdn.sspai.com/2019/01/14/0e9ec29fe5066ede4eda17321c291327.jpg" data-index="14"><figcaption class="ss-image-caption">文本文件预览</figcaption></figure><p></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/88443742d394b28a40a04480e3ccb7f0.jpg?imageView2/2/w/1120/q/40/interlace/1/ignore-error/1" alt="音乐文件预览，无损格式也没有问题" title="音乐文件预览，无损格式也没有问题" data-original="https://cdn.sspai.com/2019/01/14/88443742d394b28a40a04480e3ccb7f0.jpg" data-index="15"><figcaption class="ss-image-caption">音乐文件预览，无损格式也没有问题</figcaption></figure><p></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://i.loli.net/2019/01/13/5c3ab85894cb0.jpg?imageView2/2/w/1120/q/40/interlace/1/ignore-error/1" alt="视频文件预览" title="视频文件预览" data-original="https://i.loli.net/2019/01/13/5c3ab85894cb0.jpg" data-index="16"><figcaption class="ss-image-caption">视频文件预览</figcaption></figure><p></p>
<h3 id="ss-3-1547443243025" class="ss-hIdChildren-5">文件夹预览</h3>
<p>在 Windows 系统的文件夹里找一个文件是非常痛苦的，当你记不清文件名字或者想简单浏览一下文件夹下的内容的时候，你就不得不将一层一层的文件夹点开，如果点错了，还要在一层一层点击返回上一级，在 QTTabBar 里，你可以通过文件夹预览来解决这个问题。在设置里的「子文件夹」页面打开子文件夹功能之后，我们就可以在文件夹末尾的小箭头开启我们的文件夹预览。除此之外，还可以在标签栏的左边单击，同样可以唤出文件夹预览的功能。</p>
<p>在 QTTabBar 的文件夹预览中，你不仅可以看到子文件夹和子文件，还可以直接预览文件，打开文件和打开文件夹。</p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/c00aff70a5b54bc5d69b0dd916edcd05.gif" alt="从文件夹末尾的小箭头即可打开文件夹预览" title="从文件夹末尾的小箭头即可打开文件夹预览" data-original="https://cdn.sspai.com/2019/01/14/c00aff70a5b54bc5d69b0dd916edcd05.gif" data-index="17"><figcaption class="ss-image-caption">从文件夹末尾的小箭头即可打开文件夹预览</figcaption></figure><p></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://i.loli.net/2019/01/13/5c3abb3d5f57c.jpg?imageView2/2/w/1120/q/40/interlace/1/ignore-error/1" alt="从标签栏也能快速浏览层层叠叠的子文件夹和文件" title="从标签栏也能快速浏览层层叠叠的子文件夹和文件" data-original="https://i.loli.net/2019/01/13/5c3abb3d5f57c.jpg" data-index="18"><figcaption class="ss-image-caption">从标签栏也能快速浏览层层叠叠的子文件夹和文件</figcaption></figure><p></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/9f44b694c78b9566fe11c915121b868a.gif" alt="桌面上的文件夹也没有问题" title="桌面上的文件夹也没有问题" data-original="https://cdn.sspai.com/2019/01/14/9f44b694c78b9566fe11c915121b868a.gif" data-index="19"><figcaption class="ss-image-caption">桌面上的文件夹也没有问题</figcaption></figure><p></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/243757777f8bb88b2491b673f96f1b14.gif" alt="甚至是文件夹的快捷方式都可以！" title="甚至是文件夹的快捷方式都可以！" data-original="https://cdn.sspai.com/2019/01/14/243757777f8bb88b2491b673f96f1b14.gif" data-index="20"><figcaption class="ss-image-caption">甚至是文件夹的快捷方式都可以！</figcaption></figure><p></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://i.loli.net/2019/01/13/5c3abb7437e21.jpg?imageView2/2/w/1120/q/40/interlace/1/ignore-error/1" alt="文件预览也不可缺少" title="文件预览也不可缺少" data-original="https://i.loli.net/2019/01/13/5c3abb7437e21.jpg" data-index="21"><figcaption class="ss-image-caption">文件预览也不可缺少</figcaption></figure><p></p>
<h2 id="ss-2-1547443243025" class="ss-hId-7" hid="ss-hId-7">高级使用</h2>
<h3 id="ss-3-1547443243025" class="ss-hIdChildren-6">主题</h3>
<p>在 QTTabBar 中你可以自己定义标签栏的样式，图标、字体、颜色通通都可以改，官方还提供了类似主题商店的功能，让大家可以上传分享自己的主题。</p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/0404ee8a833e258cafe67d9e08431092.jpg?imageView2/2/w/1120/q/40/interlace/1/ignore-error/1" alt="主题商店" title="主题商店" data-original="https://cdn.sspai.com/2019/01/14/0404ee8a833e258cafe67d9e08431092.jpg" data-index="22"><figcaption class="ss-image-caption">主题商店</figcaption></figure><p></p>
<p>但请容许我小小吐个槽，官方主题商店里面的主题实在是太丑了，很多都还停留在10年前的样式，所以原谅我没能找到一个比默认主题更好看的主题来给大家做演示，所以喜欢折腾样式的同学可以自己去寻找适合自己的风格。</p>
<p>总的来说，这个功能最重要的作用还是让有绘画能力的你可以选择拓展制作自己喜欢的主题样式。</p>
<h3 id="ss-3-1547443243025" class="ss-hIdChildren-7">插件</h3>
<p>一款能被我极力推荐的软件，一定不能缺席的就是高度的可自定义能力，作为程序员的我，对「高度的可自定义」的标准几乎只有一个，那就是「可编程」，只有自定义的程度到达了方法和流程的级别，才能是真正的自定义，因为这样才是完完全全地把「定义属于自己的功能」的权利交到了用户的手上。</p>
<p>尽管我并不是对每一款可编程的软件都制作了自己的插件，但拥有可编程的能力就意味着这个软件拥有更多的可能性，而且已经考虑到开放可编程支持的软件，其本身的实力也肯定达到了一定的程度，毕竟开放出稳定的API并做好管理可不是一件简单的事情。</p>
<p>插件的使用非常简单，只需要在设置中插件的选项卡里点击添加插件的按钮，找到插件的 dll 文件加载进去即可，官网上也提供了几款插件供我们使用，基本上都是一些功能按钮，如「选择相同后缀名的文件」、「选择文件大小为0的文件」等，大家可以自行下载体验，在此我就不一一截图说明了。</p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/13a72946a2d66be97c461b3e474161e3.jpg?imageView2/2/w/1120/q/40/interlace/1/ignore-error/1" alt="QTTabBar 的插件" title="QTTabBar 的插件" data-original="https://cdn.sspai.com/2019/01/14/13a72946a2d66be97c461b3e474161e3.jpg" data-index="23"><figcaption class="ss-image-caption">QTTabBar 的插件</figcaption></figure><p></p>
<p> QTTabBar 在官网上的插件并不多，只有寥寥几个，而且都是好几年前的，但我想得到的功能 QTTabBar 都已经包揽在内置的功能里了，需要插件进行额外补充的痛点几乎已经没有，这大概也是插件稀少的原因吧（QTTabBar 的功能实在是太全面了）。</p>
<h3 id="ss-3-1547443243025" class="ss-hIdChildren-8">脚本</h3>
<p>除了插件，QTTabBar 还提供了轻量级的自动化实现，即使用脚本实现一些简单的功能，QTTabBar 的脚本可以使用 JavaScript 编写。</p>
<p>下面我使用 JavaScript 演示一下 QTTabBar 提供的脚本功能，下面这个脚本提供了一个「在同级文件夹里前后切换」的功能。</p>
<ul>
<li>将下面的代码保存为名为「QtTabBar_next_prev_folder.js」文本文件；</li>
</ul>
<pre><code class="lang-javascript">var qs = new ActiveXObject("QTTabBarLib.Scripting");
var wnd = qs.activewindow;
if (wnd) {
    var lookingForNext = WScript.Arguments.Unnamed.length == 0 || WScript.Arguments.Unnamed(0) == "next";
    var activeTab = wnd.ActiveTab;
    var currentPath = activeTab.Path;
    var fso = new ActiveXObject("Scripting.FileSystemObject");
    var currentFolderObject = fso.GetFolder(currentPath);
    var availablePaths = new Array();
    var currentIndex = -1;
    var i = -1;
    if (currentFolderObject.IsRootFolder)
    {
        var currentDrive = currentFolderObject.Drive;
        var enumerator = new Enumerator(fso.Drives);
        for (; !enumerator.atEnd(); enumerator.moveNext()) {
            var driveObject = enumerator.item();
            i++;
            availablePaths[i] = driveObject.Path;
            if (driveObject.Path == currentDrive) {
                currentIndex = i;
            }
        }
    }
    else
    {
        var enumerator = new Enumerator(currentFolderObject.ParentFolder.SubFolders);
        for (; !enumerator.atEnd(); enumerator.moveNext()) {
            var subFolder = enumerator.item();
            if (
                !(subFolder.attributes &amp; 4)
                &amp;&amp; !(subFolder.attributes &amp; 1024)
            ) {
                i++;
                availablePaths[i] = subFolder.Path;
            }
            if (subFolder.Path == currentFolderObject.Path) {
                currentIndex = i;
            }
        }
    }
    if (currentIndex &gt;= 0)
    {
        var step = lookingForNext ? 1 : -1;
        var newIndex = (availablePaths.length + currentIndex + step) % availablePaths.length;
        activeTab.NavigateTo(availablePaths[newIndex]);
    }
}
</code></pre>
<ul>
<li>在 QTTabBar 设置中的「命令按钮」面板里添加一个按钮，在「命令的类型」选择「文件和文件夹」，在「按钮的类型」选择「按钮」，在「图表路径」选择你喜欢的图标，在「路径」中填「%SystemRoot%\System32\cscript.exe」，「参数」中填「"C:\Users\lanyu\Desktop\QtTabBar_next_prev_folder.js" prev」，这里的「C:\Users\lanyu\Desktop」需要根据你保存的脚本的实际路径填写，最后确认保存；</li>
</ul>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/280b00ee3ce564f7dabd74b2daf31915.jpg?imageView2/2/w/1120/q/40/interlace/1/ignore-error/1" alt="添加命令按钮" title="添加命令按钮" data-original="https://cdn.sspai.com/2019/01/14/280b00ee3ce564f7dabd74b2daf31915.jpg" data-index="24"><figcaption class="ss-image-caption">添加命令按钮</figcaption></figure><p></p>
<ul>
<li>启用 QTTabBar 的 QT Command Bar，这是 QTTabBar 用来放置功能按钮的按钮栏，默认已经有许多快捷的功能按钮供你使用了，然后我们把新建的按钮拖动到 QT Command Bar 上；</li>
</ul>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/b7bda397100173e6535a5161edc49b64.jpg?imageView2/2/w/1120/q/40/interlace/1/ignore-error/1" alt="启用 QT Command Bar" title="启用 QT Command Bar" data-original="https://cdn.sspai.com/2019/01/14/b7bda397100173e6535a5161edc49b64.jpg" data-index="25"><figcaption class="ss-image-caption">启用 QT Command Bar</figcaption></figure><p></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/cc36c948277c8598a810974f028ea660.jpg?imageView2/2/w/1120/q/40/interlace/1/ignore-error/1" alt="拖动新创建的按钮到 QT Command Bar 上" title="拖动新创建的按钮到 QT Command Bar 上" data-original="https://cdn.sspai.com/2019/01/14/cc36c948277c8598a810974f028ea660.jpg" data-index="26"><figcaption class="ss-image-caption">拖动新创建的按钮到 QT Command Bar 上</figcaption></figure><p></p>
<ul>
<li>根据上述的步骤再创建一个向下切换的按钮，只需要将「参数」中的「prev」改为「next」。<br>脚本的效果如下：</li>
</ul>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/53c84fa3e2cf139625088884cd19a4d1.jpg?imageView2/2/w/1120/q/40/interlace/1/ignore-error/1" alt="在同级的文件夹中前后切换" title="在同级的文件夹中前后切换" data-original="https://cdn.sspai.com/2019/01/14/53c84fa3e2cf139625088884cd19a4d1.jpg" data-index="27"><figcaption class="ss-image-caption">在同级的文件夹中前后切换</figcaption></figure><p></p>
<h3 id="ss-3-1547443243025" class="ss-hIdChildren-9">快捷键</h3>
<p>快捷键的作用在于将本来隐藏在菜单里最常用的功能放在触手可及的地方，这个地方自然就是键盘，QTTabBar 也提供了可供自定义快捷键的功能，几乎所有的操作都可以为其设置一个快捷键，从下面的快捷键列表中可见一斑，除此之外， QTTabBar 还提供了丰富的鼠标快捷键的设置，几乎所有的功能，甚至是我们安装的插件的功能都可以设置对应的快捷键，这也极大满足了键盘爱好者的口味。</p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/5bd0091bfc0e69dd310c9a004ccef77f.jpg?imageView2/2/w/1120/q/40/interlace/1/ignore-error/1" alt="键盘快捷键设置" title="键盘快捷键设置" data-original="https://cdn.sspai.com/2019/01/14/5bd0091bfc0e69dd310c9a004ccef77f.jpg" data-index="28"><figcaption class="ss-image-caption">键盘快捷键设置</figcaption></figure><p></p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/f6a8d14f1737e9589d201a75a222c6ed.jpg?imageView2/2/w/1120/q/40/interlace/1/ignore-error/1" alt="鼠标快捷键设置" title="鼠标快捷键设置" data-original="https://cdn.sspai.com/2019/01/14/f6a8d14f1737e9589d201a75a222c6ed.jpg" data-index="29"><figcaption class="ss-image-caption">鼠标快捷键设置</figcaption></figure><p></p>
<h2 id="ss-2-1547443243025" class="ss-hId-8" hid="ss-hId-8">其他</h2>
<h3 id="ss-3-1547443243025" class="ss-hIdChildren-10">双击空白处返回上一级</h3>
<p>如果说有一个让我从此对其他资源管理器增强软件失去兴趣的功能，莫过于这个「双击空白处返回上一级」，只要在设置里开启了这个功能，那么你就可以在文件夹空白处双击，快速返回上一级文件夹，从此摆脱了辛苦挪动鼠标长途跋涉到界面左上角再点击返回上一级，这才是真正让我入坑 QTTabbar 的真正原因，哈哈！</p>
<p></p><figure tabindex="0" class="ss-img-wrapper"><img src="https://cdn.sspai.com/2019/01/14/8c257340026c2993e848ce81afc9a056.gif" alt="双击返回上一级" title="双击返回上一级" data-original="https://cdn.sspai.com/2019/01/14/8c257340026c2993e848ce81afc9a056.gif" data-index="30"><figcaption class="ss-image-caption">双击返回上一级</figcaption></figure><p></p>
<h1 id="ss-1-1547443243025">总结</h1>
<p>限于篇幅，QTTabbar 还有很多有趣且实用的功能没有能一一展示在文章里，各位同学可以自己在设置里慢慢探索。</p>
<p>写在文章的最后，我想说的是不管是 Total Commander 、Directory Opus 还是 QTTabbar 或 Clover ，文件操作的效率提升，关键还是在于自己对文件的管理，定时对文件进行筛选和清理，不需要的文件果断放进回收站，保持文件系统的清爽和整洁，这样才能轻易做到把常用的资料放在手边，抬抬手就可以拿到，在此基础上再辅以上述的增强软件，才能在文件操作效率上获得质的飞跃。</p>
</div>

>转载自 兰缘小妖 https://sspai.com/post/52521