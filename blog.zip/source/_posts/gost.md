---
title: GO Simple Tunnel————GO语言实现的安全隧道
tags: 
  - gost
  - go simple tunnel
  - vps
categories:
  - VPS
date: 2021-05-24 21:37:00
top_img: 'linear-gradient(20deg, #0062be, #925696, #cc426e, #fb0347)'
cover: https://cdn.jsdelivr.net/gh/wdm1732418365/CDN/New%20folder/gosttunnel.png
---

> 转载自https://docs.ginuerzh.xyz/gost/

# 功能特性

多端口监听
可设置转发代理，支持多级转发(代理链)
支持标准HTTP/HTTPS/HTTP2/SOCKS4(A)/SOCKS5代理协议
Web代理支持探测防御
SOCKS5代理支持TLS协商加密
支持多种隧道类型
Tunnel UDP over TCP
本地/远程TCP/UDP端口转发
TCP/UDP透明代理
支持Shadowsocks(TCP/UDP)协议
支持SNI代理
权限控制
负载均衡
路由控制
DNS解析和代理
TUN/TAP设备

# 下载安装

## 二进制文件
https://github.com/ginuerzh/gost/releases

## 源码编译

```
git clone https://github.com/ginuerzh/gost.git
cd gost/cmd/gost
go build
```

## Docker

```
docker pull ginuerzh/gost
Ubuntu Store
sudo snap install core
sudo snap install gost
```

## Shadowsocks Android插件
[xausky/ShadowsocksGostPlugin](https://github.com/xausky/ShadowsocksGostPlugin)

# 问题建议
提交Issue: https://github.com/ginuerzh/gost/issues

Telegram讨论群: https://t.me/gogost

Google讨论组: https://groups.google.com/d/forum/go-gost

# 快速开始

> 代理节点
> 在GOST中，GOST与其他代理服务都被看作是代理节点，GOST可以自己处理请求，或者将请求转发给任意一个或多个代理节点。

## 启动运行


## 开启代理服务

![](https://cdn.jsdelivr.net/gh/wdm1732418365/CDN/New%20folder/gost001.png)

启动一个监听在8080端口的HTTP/SOCKS5代理服务：

```
gost -L :8080
```

## 开启多个代理服务

```
gost -L http2://:443 -L socks5://:1080 -L ss://aes-128-cfb:123456@:8338
```


## 使用转发代理

![](https://cdn.jsdelivr.net/gh/wdm1732418365/CDN/New%20folder/gost002.png)

```
gost -L :8080 -F 192.168.1.1:8081
```

监听在8080端口的HTTP/SOCKS5代理服务，使用192.168.1.1:8081作为上级代理进行转发。

## 使用多级转发代理(代理链)

![](https://cdn.jsdelivr.net/gh/wdm1732418365/CDN/New%20folder/gost003.png)

```
gost -L=:8080 -F=quic://192.168.1.1:8081 -F=socks5+wss://192.168.1.2:8082 -F=http2://192.168.1.3:8083 ... -F=a.b.c.d:NNNN
```

GOST按照-F设置的顺序通过代理链将请求最终转发给a.b.c.d:NNNN处理。

## 启动参数

GOST目前有以下几个参数项：

-L - 指定本地服务配置，可设置多个。

-F - 指定转发服务配置，可设置多个，构成转发链。

-C - 指定外部配置文件。

-D - 开启Debug模式，更详细的日志输出。

-V - 查看版本，显示当前运行的gost版本号。

## 配置文件

除了通过命令行直接配置服务外，也可以通过-C参数指定外部配置文件来设置参数：

```
gost -C gost.json
```

配置文件为标准json格式：

```
{
    "Debug": true,
    "Retries": 0,
    "ServeNodes": [
        ":8080",
        "ss://chacha20:12345678@:8338"
    ],
    "ChainNodes": [
        "http://192.168.1.1:8080",
        "https://10.0.2.1:443"
    ],
    "Routes": [
        {
            "Retries": 1,
            "ServeNodes": [
                "ws://:1443"
            ],
            "ChainNodes": [
                "socks://:192.168.1.1:1080"
            ]
        },
        {
            "Retries": 3,
            "ServeNodes": [
                "quic://:443"
            ]
        }
    ]
}
```


格式说明：

Debug - 对应命令行参数-D。(2.4+)

Retries - 通过代理链建立连接失败后的重试次数。(2.5+)

ServeNodes - 必须项，等同于命令行参数-L。

ChainNodes - 等同于命令行参数-F。

Routes - 可选参数，额外的服务列表，每一项都拥有独立的转发链。(2.5+)


# 节点配置

> 逻辑分层
> 在GOST中一个代理服务逻辑上被分成两层：协议层(Protocol)和传输层(Transport)，每层有若干可选的类型，两层之间相互独立，并可以任意组合使用。

当GOST去连接一个代理节点时，会先按照传输层设置的传输类型进行交互，当传输层建立以后，再按照协议层设置的协议类型进行交互。

## 协议类型(Protocols)
支持的协议类型有：

http - HTTP

http2 - HTTP2

socks4 - SOCKS4 (2.4+)

socks4a - SOCKS4A (2.4+)

socks5 - SOCKS5

ss - Shadowsocks

ss2 - Shadowsocks with AEAD support (2.8+)

sni - SNI (2.5+)

forward - Forward

relay - TCP/UDP relay (2.11+)

## 传输类型(Transports)
支持的传输类型有：

tcp - 原始TCP

tls - TLS

mtls - Multiplex TLS，在TLS上增加多路复用功能 (2.5+)

ws - Websocket

mws - Multiplex Websocket，在Websocket上增加多路复用功能 (2.5+)

wss - Websocket Secure，基于TLS加密的Websocket

mwss - Multiplex Websocket Secure，在基于TLS加密的Websocket上增加多路复用功能 (2.5+)

kcp - KCP (2.3+)

quic - QUIC (2.4+)

ssh - SSH (2.4+)

h2 - HTTP2 (2.4+)

h2c - HTTP2 Cleartext (2.4+)

obfs4 - OBFS4 (2.4+)

ohttp - HTTP Obfuscation (2.7+)

otls - TLS Obfuscation (2.11+)

## 配置格式
端口转发相关的节点配置格式请参考端口转发。

在GOST中节点的配置为类URL格式(适用于-L和-F参数)：

```
[scheme://][user:pass@host]:port[?param1=value1&param2=value2]
```

## scheme
scheme可以是单独的协议类型或传输类型，或是二者的组合，也可以是空。

## 不指定任何类型
传输层默认为是原始TCP类型。

对于-L参数，协议层默认为是HTTP & SOCKS5，对于-F参数，协议层默认为是HTTP类型。

```
gost -L :8080 -F :8888
```

## 仅指定协议类型
当仅指定协议类型时，传输层默认为原始TCP类型。

```
gost -L http://:8080 -F socks5://:1080
```

## 仅指定传输类型
当仅指定传输类型时，对于-L参数，协议类型默认为HTTP+SOCKS5。对于-F参数，协议层默认为是HTTP类型。

```
gost -L tls://:443 -F ws://:1443
```


## 组合使用

```
gost -L http+tls://:443 -F socks5+wss://:1443
```


## 特殊的schemes

除了上述的类型外，有几个比较特殊的shemes：

https - 简写形式，等同于http+tls

redirect - TCP透明代理 (2.3+)

```
gost -L redirect://:12345
```

ssu - Shadowsocks UDP relay

```
gost -L ssu://chacha20:123456@:8338
```

## 节点认证

## user:pass
通过user:pass指定服务的认证信息。对于shadowsocks，user为加密类型。

```
gost -L admin:123456@:8080 -F ss://chacha20:123456@:8338
```

## auth参数 (2.9.2+)
如果认证信息中包含特殊字符，则可以通过auth参数来设置：

```
gost -L :8080?auth=YWRtaW46MTIzNDU2 -F ss://:8338?auth=Y2hhY2hhMjA6QWEjJiEkMTIzNEA1Njc4
```


auth的值为user:passbase64编码值

## secrets参数

也可以通过secrets参数来设定多组认证信息：

```
gost -L=:8080?secrets=secrets.txt
```

secrets.txt文件格式为按行分割的认证信息，每一行认证信息为用空格分割的user-pass对，以 # 开始的行为注释行。

```
# period for live reloading
reload      10s

# username password

admin           #123456
test\user001    123456
test.user@002   12345678
```

reload - 此配置文件支持热更新。此选项用来指定文件检查周期，默认关闭热更新。

注意： 当secrets参数用于shadowsocks协议时，仅会使用第一项作为认证信息。

> 所有的认证信息都是用于协议层(Protocol)。

# HTTPS(S)

HTTP是GOST支持的一种协议类型(Protocol)，配合各种传输类型(Transport)可以很灵活的构建代理服务：

## 标准HTTP代理服务

```
gost -L http://:8080
```

这是一种最基本的也是最普遍使用的代理服务类型，本身没有任何加密机制。

## 标准HTTPS代理服务

```
gost -L https://:443
```

使用了TLS加密的HTTP代理服务。

## HTTP Over Websocket

```
gost -L http+ws://:8080
```
或
```
gost -L http+wss://:443
```
使用Websocket (secure)作为传输类型。

## HTTP Over KCP
```
gost -L http+kcp://:8388
```

使用KCP作为传输类型。

# HTTP2

在GOST中HTTP2有两种模式：代理模式和隧道模式。

## 代理模式
在代理模式中，HTTP2被用作协议类型，传输类型必须为空。
```
gost -L http2://:443
```
443端口就是一个标准的HTTP2代理服务。

代理模式下仅支持使用TLS加密的HTTP2协议，不支持明文HTTP2传输。

## 隧道模式

在隧道模式中，HTTP2被用作传输类型：h2, h2c。
```
gost -L socks5+h2://:443
```
或
```
gost -L http+h2c://:443
```
隧道模式下支持加密(h2)和明文(h2c)两种模式。

参数说明
path - (2.9+) 可选，指定HTTP请求URI。

# 探测防御

GOST在2.7版本中增加了对HTTP/HTTPS/HTTP2代理的探测防御功能。当代理服务收到非法请求时，会按照探测防御策略返回对应的响应内容。

> 只有当代理服务开启了用户认证，探测防御功能才有效。

```
gost -L="http2://admin:123456@:443?probe_resist=code:400&knock=www.example.com"
```

## probe_resist

代理服务通过probe_resist参数来指定防御策略。参数值的格式为：type:value。

type可选值有:

code - 对应value为HTTP响应码，代理服务器会回复客户端指定的响应码。例如：probe_resist=code:404

web - 对应的value为URL，代理服务器会使用HTTP GET方式访问此URL，并将响应返回给客户端。例如: probe_resist=web:example.com/page.html

host - 对应的value为主机地址，代理服务器会将客户端请求转发给设置的主机地址，并将主机的响应返回给客户端，代理服务器在这里相当于端口转发服务。例如：probe_resist=host:example.com:8080

file - 对应的value为本地文件路径，代理服务器会回复客户端200响应码，并将指定的文件内容作为Body发送给客户端。例如：probe_resist=file:/path/to/file.txt

## knock（2.8+)

开启了探测防御功能后，当认证失败时服务器默认不会响应407 Proxy Authentication Required，但某些情况下客户端需要服务器告知代理是否需要认证(例如Chrome中的SwitchyOmega插件)。通过knock参数设置一个私有地址，只有访问此地址时服务器才会发送407响应。

此功能可应用于HTTP，HTTPS和HTTP/2代理：

```
gost -L=http://admin:123456@:8080?probe_resist=code:403
```
```
gost -L=https://admin:123456@:443?probe_resist=host:www.example.com:8080
```
```
gost -L=http2://admin:123456@:443?probe_resist=file:/send/to/client/file.txt
```

# SCOKS


SOCKS是GOST支持的协议类型(Protocol)，SOCKS协议有三个版本: SOCKS4, SOCKS4A和SOCKS5。

## SOCKS4

```
gost -L socks4://:1080
```

标准的SOCKS4代理服务，同时兼容SOCKS4A协议。

## SOCKS4A

```
gost -L socks4a://:1080
```

标准的SOCKS4A代理服务。

> SOCKS4(A)当前仅支持CONNECT方法，不支持BIND方法。


## SOCKS5

```
gost -L socks5://:1080
```
## SOCKS5协商加密
GOST支持标准SOCKS5协议的no-auth(0x00)和user-pass(0x02)方法，并在此基础上扩展了两个：tls(0x80)和tls-auth(0x82)，用于数据加密。

## 服务端
```
gost -L=socks5://:1080
```
## 客户端
```
gost -L=:8080 -F=socks5://server_ip:1080?notls=true
```
如果两端都是GOST(如上)则数据传输会被加密(协商使用tls或tls-auth方法)，否则使用标准SOCKS5进行通讯(no-auth或user/pass方法)。

notls - (2.9.1+) 通过此参数可以禁用协商加密，默认值：false。

## SOCKS5 UDP Relay

GOST中SOCKS5同时也支持UDP Relay，并支持TCP-over-UDP特性。

不设置转发代理

![](https://cdn.jsdelivr.net/gh/wdm1732418365/CDN/New%20folder/udp01.png)

GOST做为标准SOCKS5代理处理UDP数据。

设置转发代理

![](https://cdn.jsdelivr.net/gh/wdm1732418365/CDN/New%20folder/udp02.png)

设置多个转发代理(代理链)

![](https://cdn.jsdelivr.net/gh/wdm1732418365/CDN/New%20folder/udp03.png)

当设置转发代理时，GOST会使用UDP-over-TCP方式转发UDP数据。proxy1 - proxyN可以为任意类型代理。

> 如果要转发SOCKS5的BIND和UDP请求，代理链的末端(最后一个-F参数)必须是GOST SOCKS5类型代理。
SOCKS协议也可以与各种传输类型(Transport)组合使用

## SOCKS5 Over TLS
```
gost -L socks5+tls://:1080
```
使用TLS加密的SOCKS5代理服务。

## SOCKS5 Over QUIC
```
gost -L socks5+quic://:1080
```

# Shadowsocks

Shadowsocks是GOST支持的一种协议类型(Protocol)。

GOST对shadowsocks的支持是基于[shadowsocks/shadowsocks-go](https://github.com/shadowsocks/shadowsocks-go)库。

## 使用说明

> 从2.10.1+开始加密变为可选。
## TCP

### 参数说明

nodelay - true/false (默认值为false)。默认情况下ss协议会等待客户端的请求数据，当收到请求数据后会把协议头部信息与请求数据一起发给服务端。当此参数设为true后，协议头部信息会立即发给服务端，不再等待客户端的请求。

### 服务端
```
gost -L=ss://chacha20:password@:8338
```
### 客户端
```
gost -L=:8080 -F=ss://chacha20:password@server_ip:8338?nodelay=true
```
## AEAD加密
> 2.10.1+后，ss2功能已经合并到ss中，可以直接在ss中使用AEAD加密，ss2已废弃。
在2.8版本中，GOST基于shadowsocks/go-shadowsocks2增加了对AEAD加密的支持。

### 服务端
```
gost -L=ss2://AEAD_CHACHA20_POLY1305:password@:8338
```
### 客户端
```
gost -L=:8080 -F=ss2://AEAD_CHACHA20_POLY1305:password@server_ip:8338
```
## 组合传输层

Shadowsocks协议可以与各种传输类型(Transport)组合使用

### Shadowsocks Over TLS
```
gost -L ss+tls://chacha20:123456@:8338
```
### Shadowsocks Over KCP
```
gost -L ss+kcp://chacha20:123456@:8338
```
## UDP
### 服务端
```
gost -L=ssu://method:password@:8338?ttl=60s
```
ttl - (2.10+) 传输通道超时时间，默认为60s。

## 2.10+后的变化

## 客户端支持

ssu可以用在转发链中用来转发UDP数据：
```
gost -L udp://:5353/8.8.8.8:53 -F=ssu://method:password@:8338
```
## 加密方法
加密变为可选。

基于[shadowsocks/go-shadowsocks2](https://github.com/shadowsocks/shadowsocks-go)增加了对AEAD加密的支持，且兼容老版本中的加密方式。

当设置了加密，会优先使用(shadowsocks/shadowsocks-go)库，若加密方法不支持，则切换到(shadowsocks/go-shadowsocks2)库。

## 组合传输层
ssu在2.10版本中，变成了一种协议类型，可以与各种传输类型组合使用：
```
gost -L ssu+kcp://:8338
```
```
gost -L ssu+wss://:443
```
默认情况下ssu等同于ssu+udp，传输层为原始UDP协议。这种情况下，GOST会使用shadowsocks本身的UDP relay协议进行数据转发。

如果指定了其他传输类型，则会使用SOCKS5的UDP relay协议进行数据转发。

> ssu仅能用于转发UDP数据，转发TCP数据的行为未定义。
> 当用在转发链中时，ssu必须为转发链的最后一个节点。
> 当ssu+udp用于转发链中时，转发链中不能存在其他节点。

# SNI

SNI是GOST支持的一种协议类型(Protocol)。

## 使用说明
## 服务端
```
gost -L sni://:443
```
## 客户端
可以通过配置hosts直接使用，或使用GOST进行转发:
```
gost -L :8080 -F sni://server_ip:443
```
## Host混淆
在GOST中SNI客户端可以通过host参数来指定Host别名：
```
gost -L :8080 -F sni://server_ip:443?host=example.com
```
SNI客户端会将TLS握手或HTTP请求头中的Host替换为host参数指定的内容。

SNI协议可以与各种传输类型(Transport)组合使用

## SNI Over TLS
```
gost -L sni+tls://:443
```
## SNI Over Websocket
```
gost -L sni+ws://:443
```

# TLS

TLS是GOST支持的一种传输类型(Transport)。

## 使用说明
## 标准TLS
### 服务端
```
gost -L tls://:443
```
### 客户端
```
gost -L :8080 -F tls://server_ip:443
```
## 多路复用TLS
GOST在TLS基础之上扩展出具有多路复用(Multiplex)特性的TLS传输类型(mtls)。

### 服务端
```
gost -L mtls://:443
```
### 客户端
```
gost -L :8080 -F mtls://server_ip:443
```
## TLS证书
GOST内置了TLS证书，如果需要使用自定义TLS证书，有两种方法：

在GOST运行目录放置cert.pem(公钥)和key.pem(私钥)两个文件即可，GOST会自动加载运行目录下的cert.pem和key.pem文件。

使用key和cert参数指定证书文件路径：
```
gost -L="tls://:443?cert=/path/to/my/cert/file&key=/path/to/my/key/file"
```
## 证书校验
对于客户端可以通过secure参数开启服务器证书和域名校验，默认不校验证书:
```
gost -L=:8080 -F="tls://server_domain_name:443?secure=true"
```
当需要校验证书时，节点配置中的server_domain_name部分必须填写服务器的域名。

## 证书锁定
对于客户端可以通过ca参数指定CA证书进行证书锁定(Certificate Pinning):
```
gost -L=:8080 -F="tls://:443?ca=ca.pem"
```
> 以上参数可以用于所有支持TLS的服务，例如HTTP2, QUIC, WSS, SSH, SOCKS5。
## 双向证书校验(2.11.1+)
服务端可以通过ca参数指定CA证书来对客户端证书进行强制校验：
```
gost -L="tls://:443?cert=certfile&key=keyfile&ca=cafile"
```
此时客户端必须提供自己的证书：
```
gost -L=:8080 -F="tls://server_ip:443?cert=certfile&key=keyfile"
```

# Websocket

Websocket是GOST支持的传输类型(Transport)。

## 使用说明
```
gost -L "ws://:8080?path=/ws&rbuf=4096&wbuf=4096&compression=false"
```
## 参数说明
path - 设置请求URI，默认值为/ws

rbuf - 接收缓冲区大小，默认值：4096

wbuf - 发送缓冲区大小，默认值：4096

compression - 是否使用压缩，默认值：false

GOST中的Websocket有四种类型：

## 标准Websocket
```
gost -L ws://:8080
```
未加密的websocket隧道。

## Multiplex Websocket
```
gost -L mws://:8080
```
具有多路复用特性的未加密websocket隧道。

## Websocket Secure
```
gost -L wss://:443
```
使用TLS加密的Websocket隧道。

## Multiplex Websocket Secure
```
gost -L mwss://:443
```
具有多路复用特性并使用TLS加密的Websocket隧道。

# KCP

KCP是GOST支持的一种传输类型(Transport)。

GOST对KCP的支持是基于xtaci/kcp-go和xtaci/kcptun库。

## 使用说明
## 服务端
```
gost -L=kcp://:8388
```
## 客户端
```
gost -L=:8080 -F=kcp://server_ip:8388
```
## 配置
GOST中内置了一套默认的KCP配置项，默认值与xtaci/kcptun中的一致。可以通过参数c指定外部配置文件：
```
gost -L=kcp://:8388?c=/path/to/conf/file
```
配置文件格式：

```
{
    "key": "it's a secrect",
    "crypt": "aes",
    "mode": "fast",
    "mtu" : 1350,
    "sndwnd": 1024,
    "rcvwnd": 1024,
    "datashard": 10,
    "parityshard": 3,
    "dscp": 0,
    "nocomp": false,
    "acknodelay": false,
    "nodelay": 0,
    "interval": 40,
    "resend": 0,
    "nc": 0,
    "sockbuf": 4194304,
    "keepalive": 10,
    "snmplog": "",
    "snmpperiod": 60,
    "tcp": false
}
```
配置文件中的参数说明请参考[kcptun](https://github.com/xtaci/kcptun#usage)。

> 若要在代理链中使用KCP节点，则此代理链中只能有一个KCP节点，且此节点只能作为代理链的第一个节点。
## Fake TCP (2.9.1+)
可以通过tcp参数或配置文件中的tcp项开启伪TCP模式。

> 此功能仅适用于Linux。
## 服务端
```
gost -L=kcp://:8388?tcp=true
```
## 客户端
```
gost -L=:8080 -F=kcp://server_ip:8388?tcp=true
```

# QUIC

QUIC是GOST支持的一种传输类型(Transport)。GOST对QUIC的支持是基于[lucas-clemente/quic-go](https://github.com/lucas-clemente/quic-go)库。

## 使用说明
## 服务端
```
gost -L=quic://:6121
```
## 客户端
```
gost -L=:8080 -F=quic://server_ip:6121
```
## 心跳
客户端可以通过keepalive参数开启心跳检测
```
gost -L=:8080 -F=quic://server_ip:6121?keepalive=true
```
> 若要在代理链中使用QUIC节点，则此代理链中只能有一个QUIC节点，且此节点只能作为代理链的第一个节点。

# SSH

SSH是GOST支持的一种传输类型(Transport)。

## 使用说明
## 服务端
```
gost -L=ssh://:2222
```
## 客户端
```
gost -L=:8080 -F=ssh://server_ip:2222?ping=60
```
客户端可以通过ping参数设置心跳包发送周期，单位为秒。默认不发送心跳包。

## 端口转发
GOST中的SSH也支持标准SSH协议的端口转发功能，具体使用方法请参考端口转发

## PubKey认证 (2.11+)
服务端
```
gost -L="ssh://:2222?ssh_authorized_keys=/path/to/authorized_keys"
```
ssh_authorized_keys - 客户端公钥列表文件

客户端
```
gost -L :8080 -F=ssh://server_ip:2222?ssh_key=/path/to/id_rsa"
```
ssh_key - 客户端私钥文件

# Simple-obfs

Simple-obfs是GOST支持的一种传输类型(Transport)。

Simple-obfs兼容[shadowsocks/simple-obfs](https://github.com/shadowsocks/simple-obfs)和Android上的[Simple Obfuscation](https://play.google.com/store/apps/details?id=com.github.shadowsocks.plugin.obfs_local)插件。

## 使用说明
## obfs-http
服务端
```
gost -L=ss+ohttp://chacha20:123456@:8338
```
客户端
```
gost -L=:8080 -F=ss+ohttp://chacha20:123456@server_ip:8338?host=bing.com
```
客户端可以通过host参数自定义请求Host。

## obfs-tls (2.11+)
服务端
```
gost -L=ss+otls://chacha20:123456@:8338
```

客户端

```
gost -L=:8080 -F=ss+otls://chacha20:123456@server_ip:8338?host=bing.com
```

客户端可以通过host参数自定义请求Host。

> obfs-tls目前仅支持[shadowsocks/shadowsocks-go](https://github.com/shadowsocks/shadowsocks-go)库所支持的加密方式，不支持AEAD加密。

# Obfs4

Obfs4是GOST支持的一种传输类型(Transport)。

首先要运行服务端，生成客户端访问的URL：
```
gost -L ss+obfs4://:18080
```
当正常启动后，会在控制台显示URL
```
ss+obfs4://:18080/?cert=06ss%2FlcDWVkTZLXLcRkH8tozyP0aUXmOm%2BuT5KtbkEP%2BTnCqNumFx9p218Vy0WityAM0Kg&iat-mode=0
```
然后再使用生成的参数启动客户端：
```
gost -L :8080 -F ss+obfs4://server_ip:18080/?cert=06ss%2FlcDWVkTZLXLcRkH8tozyP0aUXmOm%2BuT5KtbkEP%2BTnCqNumFx9p218Vy0WityAM0Kg&iat-mode=0
```
这里生成的URL不包含IP，所以如果客户端与服务端不是同一台主机，就要指定服务端的IP。

# 透明代理

GOST在2.3版本中增加了对TCP透明代理的支持，在2.10版本中增加了对UDP透明代理的支持。

> 透明代理仅支持Linux系统。

## TCP

```
gost -L red://:12345 -F 192.168.1.1:1080
```
## 本地全局TCP代理：
设置iptables：
```
iptables -t nat -A OUTPUT -p tcp --match multiport ! --dports 12345,1080 -j DNAT --to-destination 127.0.0.1:12345
```
## UDP (2.10+)
UDP透明代理是基于iptables的tproxy模块实现的。
```
gost -L redu://:12345?ttl=60s -F ssu://1.2.3.4:1080
```
ttl - 传输通道超时时间，默认为60s。

## 本地全局UDP代理
### 设置iptables规则
> 规则中的192.168.0.0/16为本机所在网络，1.2.3.4/32为转发服务端地址，请根据实际情况进行修改。

```
iptables -t mangle -N GOST
iptables -t mangle -N GOST_LOCAL

iptables -t mangle -A GOST -d 255.255.255.255/32 -j RETURN
iptables -t mangle -A GOST -d 127.0.0.0/8 -p udp -j RETURN
iptables -t mangle -A GOST -d 192.168.0.0/16 -p udp -j RETURN
iptables -t mangle -A GOST -p udp -j TPROXY --on-port 12345 --on-ip 0.0.0.0 --tproxy-mark 1

iptables -t mangle -A GOST_LOCAL -d 255.255.255.255/32 -j RETURN
iptables -t mangle -A GOST_LOCAL -d 192.168.0.0/16 -p udp -j RETURN
iptables -t mangle -A GOST_LOCAL -d 1.2.3.4/32 -p udp -j RETURN
iptables -t mangle -A GOST_LOCAL -p udp -j MARK --set-mark 1

iptables -t mangle -A PREROUTING -j GOST
iptables -t mangle -A OUTPUT -j GOST_LOCAL
```
设置路由表
```
ip rule add fwmark 1 table 100
ip route add local 0.0.0.0/0 dev lo table 100
```


# 端口转发


GOST从2.1版本开始增加了对端口转发的支持。

## 使用说明
端口转发服务节点的配置与普通的代理节点有所不同:
```
scheme://[bind_address]:port/[host]:hostport[,[host]:hostport]?ip=[host]:hostport][,[host]:hostport]]
```
scheme - 端口转发模式, 本地端口转发: tcp, udp; 远程端口转发: rtcp, rudp; 转发隧道: tls, kcp等传输类型。

[bind_address]:port - 本地/远程绑定地址。

[host]:hostport[,[host]:hostport] - (可选, 2.6+) 目标访问地址，支持以逗号分割的多地址形式。

## 参数说明
ip - (可选, 2.8+) 也可以通过此参数来指定目标地址。

strategy - 指定节点选择策略，round - 轮询，random - 随机, fifo - 自上而下。默认值为round。

max_fails - (2.8.1+) 指定节点连接的最大失败次数，当与一个节点建立连接失败次数超过此设定值时，此节点会被标记为死亡节点(Dead)，死亡节点不会被选择使用。默认值为1。

fail_timeout - (2.8.1+) 指定死亡节点的超时时间，当一个节点被标记为死亡节点后，在此设定的时间间隔内不会被选择使用，超过此设定时间间隔后，会再次参与节点选择。默认为30秒。

## TCP本地端口转发
将本地的TCP端口A映射到指定的目标TCP端口B，所有到端口A的数据会被转发到端口B。此功能类似于SSH的本地端口转发功能。
```
gost -L=tcp://:2222/192.168.1.1:22 [-F=..]
```
将本地TCP端口2222上的数据(通过代理链)转发到192.168.1.1:22上。

当代理链末端(最后一个-F参数)为forward+ssh类型时，GOST会直接使用SSH的本地端口转发功能:
```
gost -L=tcp://:2222/192.168.1.1:22 -F forward+ssh://:2222
```
服务端可以是标准的SSH程序，也可以是GOST的SSH转发模式：
```
gost -L forward+ssh://:2222
```
scheme必须是forward+ssh。

## TCP远程端口转发
将目标TCP端口B映射到本地TCP端口A，所有到端口B上的数据会被转发到端口A。此功能类似于SSH的远程端口转发功能。
```
gost -L=rtcp://:2222/192.168.1.1:22 [-F=... -F=socks5://172.24.10.1:1080]
```
将172.24.10.1:2222上的数据(通过代理链)转发到192.168.1.1:22上。

## SOCKS5多路复用模式
在2.5版本中，SOCKS5的BIND方法增加了对多路复用的支持，远程端口转发可以利用这个特性提高传输效率。
```
gost -L rtcp://:8080/192.168.1.1:80 -F socks5://:1080?mbind=true
```
客户端通过mbind=true参数开启SOCKS5的BIND多路复用模式。

## SSH端口转发模式
当代理链末端(最后一个-F参数)为forward+ssh类型时，GOST会直接使用SSH的远程端口转发功能:
```
gost -L=rtcp://:2222/192.168.1.1:22 -F forward+ssh://:2222
```
服务端可以是标准的SSH程序，也可以是GOST的SSH转发模式：

gost -L forward+ssh://:2222
scheme必须是forward+ssh。

## UDP本地端口转发
将本地的UDP端口A映射到指定的目标UDP端口B，所有到端口A的数据会被转发到端口B。
```
gost -L=udp://:5353/192.168.1.1:53?ttl=60s [-F=... -F=socks5://172.24.10.1:1080]
```
将本地UDP端口5353上的数据(通过代理链)转发到192.168.1.1:53上。

每一个不同的客户端(不同的端口)对应一条转发通道，每条转发通道都有超时时间，当超过此时间且在此时间段内无任何数据交互，则此通道将关闭。 可以通过ttl参数来设置超时时间，默认值为60秒。

## UDP远程端口转发
将目标UDP端口B映射到本地UDP端口A，所有到端口B上的数据会被转发到端口A。
```
gost -L=rudp://:5353/192.168.1.1:53?ttl=60s [-F=... -F=socks5://172.24.10.1:1080]
```
将172.24.10.1:5353上的数据(通过代理链)转发到192.168.1.1:53上。

每一个不同的客户端(不同的端口)对应一条转发通道，每条转发通道都有超时时间，当超过此时间且在此时间段内无任何数据交互，则此通道将关闭。 可以通过ttl参数来设置超时时间，默认值为60秒。

> 转发UDP数据时，如果有代理链，则代理链的末端(最后一个-F参数)协议必须是GOST socks5类型，传输层可以任意选择。

2.10+后本地UDP端口转发也可以使用ssu进行转发。

## 转发隧道
在2.5版本中TCP本地端口转发可以配合传输类型一起使用：

服务端:
```
gost -L tls://:443/:1443 -L sni://:1443
```
对应的scheme为传输类型，协议类型必须为空。

客户端:
```
gost -L :8080 -F forward+tls://server_ip:443
```
对应的scheme为forward+transport格式，其中协议类型必须为forward。

## 使用场景
加密
```
gost -L tls://:443/:8080 -L http://:8080
```
将8080端口的HTTP代理服务转成443端口的HTTPS代理服务

加速
```
gost -L kcp://:8388/:8338 -L ss://chacha20:123456@:8338
```
将8338端口的shadowsocks代理服务转成使用KCP传输。

# Relay

Relay是GOST(2.11+)支持的一种协议类型(Protocol)。

> Relay协议本身不具备加密功能，如果需要对数据进行加密传输，可以配合加密隧道使用。
## 使用说明
Relay协议同时具有代理和转发功能，可同时处理TCP和UDP的数据，并支持用户认证。

## 参数说明
nodelay - true/false (默认值为false)。默认情况下relay协议会等待客户端的请求数据，当收到请求数据后会把协议头部信息与请求数据一起发给服务端。当此参数设为true后，协议头部信息会立即发给服务端，不再等待客户端的请求。

## 代理功能
Relay协议可以像HTTP/SOCKS5一样用作代理协议。

服务端
```
gost -L relay+tls://username:password@:12345
```
客户端
```
gost -L :8080 -F relay+tls://username:password@:12345?nodelay=false
```
## 转发功能
Relay转发有两种模式，一种是配合端口转发使用，另一种是配合转发隧道使用。两种模式均可以同时转发TCP和UDP数据。

### 端口转发
服务端
```
gost -L relay://:12345
```
客户端
```
gost -L udp://:1053/:53 -L tcp://:1053/:53 -F relay://:12345
```
### 转发隧道
服务端
```
gost -L relay://:12345/:53
```
客户端
```
gost -L udp://:1053 -L tcp://:1053 -F relay://:12345
```

# 权限控制

服务端可以通过白名单whitelist参数和黑名单blacklist参数来控制客户端的请求是否允许被处理。 参数格式为: [actions]:[hosts]:[ports]

[actions]是一个由,分割的动作列表，可选值有: tcp(TCP转发), udp(UDP转发), rtcp(TCP远程转发), rudp(UDP远程转发), 或 *(所有动作)。

[hosts]是一个由,分割的Host列表，代表可以绑定到(rtcp,rudp)或转发到(tcp,udp)的目的主机，支持通配符(*.google.com)和*(所有主机)。

[ports]是一个由,分割的端口列表，代表可以绑定到(rtcp,rudp)或转发到(tcp,udp)的目的端口，可以是*(所有端口)。

多组权限可以通过+进行连接:

whitelist=rtcp,rudp:localhost,127.0.0.1:2222,8000-9000+udp:8.8.8.8,8.8.4.4:53(允许TCP/UDP远程端口转发绑定到localhost,127.0.0.1的2222端口和8000-9000端口范围，同时允许UDP转发到8.8.8.8:53和8.8.4.4:53)。

SSH远程端口转发只能绑定到127.0.0.1:8000
```
gost -L=forward+ssh://localhost:8389?whitelist=rtcp:127.0.0.1:8000
```
SOCKS5的TCP/UDP远程端口转发只允许绑定到大于1000的端口
```
gost -L=socks://localhost:8389?blacklist=rtcp,rudp:*:0-1000
```
SOCKS5的UDP转发只能转发到8.8.8.8:53
```
gost -L=socks://localhost:8389?whitelist=udp:8.8.8.8:53
```

# 负载均衡

> 节点组
> 一个节点组由一个或多个节点组成，每个节点可以是任意类型。 GOST代理链的每一层级都是一个节点组。

GOST在2.5版本中增加了对负载均衡的支持。负载均衡可以应用于代理链的所有层级节点。

负载均衡有两种，这里简单的称之为简单型和复杂型，两种类型可以组合使用。

## 简单型
简单型是一种类似于DNS负载均衡的功能，可以为代理节点指定多个地址：
```
gost -L=:8080 -F='http://localhost:8080?ip=192.168.1.1,192.168.1.2:8081,192.168.1.3:8082&strategy=round&max_fails=1&fail_timeout=30s' -F=socks5://localhost:1080?ip=172.20.1.1:1080,172.20.1.2:1081,172.20.1.3:1082
```
## 参数说明
ip - 指定实际的代理服务地址(以逗号分割的列表)，地址格式可以是ip[:port]或hostname[:port]，若没有指定port则默认使用URL中的port。

strategy - (2.6+) 指定节点选择策略，round - 轮询，random - 随机, fifo - 自上而下。默认值为round。

max_fails - (2.8.1+) 指定节点连接的最大失败次数，当与一个节点建立连接失败次数超过此设定值时，此节点会被标记为死亡节点(Dead)，死亡节点不会被选择使用。默认值为1。

fail_timeout - (2.8.1+) 指定死亡节点的超时时间，当一个节点被标记为死亡节点后，在此设定的时间间隔内不会被选择使用，超过此设定时间间隔后，会再次参与节点选择。默认为30秒。

> 当设置了ip参数，URL中指定的地址将会被忽略。
> 当设置了peer参数(见下方说明)，以上参数会被peer参数覆盖。

![](https://cdn.jsdelivr.net/gh/wdm1732418365/CDN/New%20folder/lb01.png)

当为一个层级指定了多个节点，GOST会将这些节点按指定顺序放在同一个节点组中。

每次客户端发送请求，代理链会先确定一条路径，对每一个节点组执行节点选择(随机或轮询)。

![](https://cdn.jsdelivr.net/gh/wdm1732418365/CDN/New%20folder/lb02.png)

相当于将上面的命令转化为：
```
gost -L=:8080 -F=http://192.168.1.3:8082 -F=socks5://172.20.1.2:1081
```
若地址比较多，可以使用外部配置文件：
```
gost -L=:8080 -F=http://localhost:8080?ip=iplist1.txt -F=socks5://localhost:1080?ip=iplist2.txt
```
配置文件的格式为(按行分割的地址列表)：
```
192.168.1.1
192.168.1.2:8081
192.168.1.3:8082
example.com:8083
```
在简单型中要求每一层级的所有节点的类型和配置保持一致。

## 复杂型
复杂型克服了简单型中的限制，可以自由指定代理链中每一层级节点组中节点的类型。

![](https://cdn.jsdelivr.net/gh/wdm1732418365/CDN/New%20folder/lb03.png)
```
gost -L=:8080 -F=kcp://192.168.1.1:8388?peer=peer1.txt -F=http2://172.20.1.1:443?peer=peer2.txt
```
客户端通过peer参数指定额外的节点配置文件，配置文件格式为：
```
# strategy for node selecting
strategy        random

max_fails       1

fail_timeout    30s

# period for live reloading
reload          10s

# peers
peer    http://:18080
peer    socks://:11080
peer    ss://chacha20:123456@:18338
```
格式说明:

strategy - 同strategy参数。

max_fails - 同max_fails参数。

fail_timeout - 同fail_timeout参数。

reload - 此配置文件支持热更新。此选项用来指定文件检查周期，默认关闭热更新。

peer - 指定节点列表。

每次客户端发送请求，代理链会确定一条路径，对每一个节点组执行节点选择(随机或轮询)。

![](https://cdn.jsdelivr.net/gh/wdm1732418365/CDN/New%20folder/lb04.png)

## 简单型+复杂型
组合使用时，代理链会将每一层级上(通过ip和peer参数)指定的所有节点放在同一个节点组中，再对每一个节点组执行节点选择(随机或轮询)，最终确定一条路径：

![](https://cdn.jsdelivr.net/gh/wdm1732418365/CDN/New%20folder/lb05.png)

完整的示例配置
```
gost.json:

{
    "Debug": false,
    "Retries": 3,
    "Routes": [
        {
            "Retries": 3,
            "ServeNodes": [
                ":8888"
            ],
            "ChainNodes": [
                ":1080?peer=peer.txt"
            ]
        }
    ]
}
```
peer.txt:
```
strategy        random
max_fails       1
fail_timeout    30s

reload          10s

# peers
peer    ss+kcp://aes-128-cfb:pass@[host]:port?ip=ips.txt
```
ips.txt:
```
host1[:port]
host2[:port]
host3[:port]
```

# 路由控制

GOST在2.6版本中增加了路由控制功能，可以通过黑白名单来控制客户端的请求。路由控制可以应用于服务节点(-L参数)和代理链的所有层级节点(-F参数)。
```
gost -L=:8080?bypass=127.0.0.1,192.168.1.0/24,.example.net -F=:1080?bypass=172.10.0.0/16,localhost,*.example.com
```


通过bypass参数来指定请求的目标地址列表(以逗号分割的IP,CIDR,域名或域名通配符地址)。

当执行代理链的节点选择时，每当确定一个代理链层级节点后，会应用此节点上的路由配置(bypass参数)，若此次请求的目标地址包含在此配置中，则代理链终止于此节点(且不包含此节点)。

若地址比较多，可以使用外部配置文件：
```
gost -L :8080?bypass=bypass.txt -F :1080?bypass=bypass2.txt
```
配置文件的格式为(地址列表和可选的配置项)：
```
# options
reload   10s
reverse  true

# bypass addresses
127.0.0.1
172.10.0.0/16
localhost
*.example.com
.example.org
```
reload - 此配置文件支持热更新。此选项用来指定文件检查周期，默认关闭热更新。

reverse - 指定是否切换为白名单。

若要转换为白名单，则通过在bypass参数值前添加~前缀：
```
gost -L=:8080?bypass=~127.0.0.1,172.10.0.0/16,localhost,*.example.com,.example.org
```
对于文件方式也是一样：
```
gost -L=:8080?bypass=~bypass.txt
```

# DNS解析

GOST在2.6版本中可以自定义DNS解析。DNS解析应用于服务节点。

每当节点收到请求时，会使用此节点上指定的DNS解析器对此请求的目标地址进行解析。

## 使用说明

```
gost -L=http://:8080?dns=8.8.8.8,1.1.1.1:53/tcp,1.1.1.1:853/tls,https://1.0.0.1/dns-query
```
## 参数项
dns - 指定DNS服务列表(以逗号分割)，每个DNS服务的格式为：ip[:port][/protocol]，其中port默认为53，protocol可选值有：udp，udp-chain，tcp，tcp-chain，tls，tls-chain，https，https-chain。默认值为udp。

## 代理链(2.10.0+)
如果需要通过代理链来连接DNS服务器，则可以使用以下protocols:

udp-chain, tcp-chain, tls-chain, https-chain
```
gost -L=http://:8080?dns=8.8.8.8/udp-chain,1.1.1.1:853/tls-chain,https-chain://dns.google/dns-query -F=socks://:1080
```
> 如果要转发udp-chain，代理链的末端(最后一个-F参数)必须是GOST socks5或ssu类型代理。
## 配置文件
也可以使用外部文件来指定DNS服务列表：
```
gost -L=:8080?dns=dns.txt
```
配置文件的格式为(按行分割的地址列表)：
```
# options
timeout     5s
# ttl       60s
reload      10s

# prefer    ipv6

# ip        1.2.3.4

# ip[:port] [protocol] [hostname]
8.8.8.8
8.8.8.8     tcp
1.1.1.1     udp
1.1.1.1:53  tcp-chain
1.1.1.1:853 tls     cloudflare-dns.com
https://1.0.0.1/dns-query   https-chain
```
timeout - DNS请求超时时间，默认5秒。

ttl - DNS缓存有效期，默认使用DNS查询返回结果中的TTL。当设置为负值，则不使用缓存。

reload - 此配置文件支持热更新。此选项用来指定文件检查周期，默认关闭热更新。

prefer - (2.8.2+) AAAA(IPv6)优先于A(IPv4)。

ip - 2.10.1+，客户端IP，设置后会开启ECS(EDNS Client Subnet)扩展功能。

DNS服务项分为三列：

第一列为DNS服务器地址，格式为ip[:port]，port默认为53.

第二列为协议类型，可选值有：udp，udp-chain，tcp，tcp-chain，tls，tls-chain，https，https-chain。 默认为udp。

第三列为DNS服务域名，当协议类型为tls，tls-chain，https，https-chain时有效，用于TLS证书校验。

## 自定义域名解析
除了可以自定义DNS服务用来解析域名外，还可以手动指定域名-IP映射关系，类似于Linux下的/etc/hosts文件功能。
```
gost -L=:8080?hosts=hosts.txt
```
配置文件的格式：
```
# options
reload  10s

# IP_address    canonical_hostname     [aliases...]
127.0.0.1       localhost
192.168.1.10    foo.mydomain.org       foo
192.168.1.13    bar.mydomain.org       bar baz
```
reload - 此配置文件支持热更新。此选项用来指定文件检查周期，默认关闭热更新。

映射表项分为三列：

第一列为IP地址。

第二列为主机名或域名。

第三列为别名，可以有多个。

# DNS代理

GOST在2.10版本中增加了DNS代理服务。

## 使用说明
```
gost -L="dns://:1053?mode=udp&dns=8.8.8.8,1.1.1.1:53/tcp,1.1.1.1:853/tls,https://1.0.0.1/dns-query"
```
## 参数项
mode - 指定代理服务的运行模式，可选值：udp，tcp，tls，https。默认值为udp。

dns - 与DNS解析中的dns参数功能和使用方式相同。

ttl - 2.10.1+，缓存过期时间，设置负值则禁用缓存，默认使用查询结果中的过期时间。

timeout - 2.10.1+，请求超时时间，默认5s。

ip - 2.10.1+，客户端IP，设置后会开启ECS(EDNS Client Subnet)扩展功能。

# TUN/TAP设备

GOST在2.9版本中增加了对TUN/TAP设备的支持。基于TUN/TAP设备可以简单的构建VPN。

## Windows
Windows下需要安装tap驱动后才能使用，可以选择安装[OpenVPN/tap-windows6](https://github.com/OpenVPN/tap-windows6)或[OpenVPN client](https://github.com/OpenVPN/openvpn)。

## TUN
使用说明
```
gost -L="tun://[method:[email protected]][local_ip]:port[/remote_ip:port]?net=192.168.123.2/24&name=tun0&mtu=1350&route=10.100.0.0/16&gw=192.168.123.1"
```
method:password - 可选，指定UDP隧道数据加密方法和密码。所支持的加密方法与[shadowsocks/go-shadowsocks2](https://github.com/shadowsocks/go-shadowsocks2)一致。

local_ip:port - 必须，本地监听的UDP隧道地址。

remote_ip:port - 可选，目标UDP地址。本地TUN设备收到的IP包会通过UDP转发到此地址。

net - 必须，指定TUN设备的地址。

name - 可选，指定TUN设备的名字，默认值为系统预设。

mtu - 可选，设置TUN设备的MTU值，默认值为1350。

route - 可选，逗号分割的路由列表:，例如：10.100.0.0/16,172.20.1.0/24,1.2.3.4/32

gw - 可选，设置TUN设备路由默认网关IP。

tcp - 可选，是否使用fake TCP隧道，默认false。

## 服务端路由(2.9.2+)
服务端可以通过设置路由表和网关，来访问客户端所在的网络。

默认网关
服务端可以通过gw参数设置默认网关，来指定route参数的路由路径。
```
gost -L="tun://:8421?net=192.168.123.1/24&gw=192.168.123.2&route=172.10.0.0/16,10.138.0.0/16"
```
发往172.10.0.0/16和10.138.0.0/16网络的数据会通过TUN隧道转发给IP为192.168.123.2的客户端。

特定网关路由
如果要针对每个路由设置特定的网关，可以通过路由配置文件来指定：
```
gost -L="tun://:8421?net=192.168.123.1/24&route=route.txt"
```
配置文件route.txt的格式为：
```
# Destination   Gateway

172.10.0.0/16   192.168.123.2
10.138.0.0/16   192.168.123.3
```
第一列为目标网络。

第二列为网关IP，若为空则使用gw参数设置的默认网关IP。

发往172.10.0.0/16网络的数据会通过TUN隧道转发给IP为192.168.123.2的客户端。 发往10.138.0.0/16网络的数据会通过TUN隧道转发给IP为192.168.123.3的客户端。

## 构建基于TUN设备的VPN (Linux)
> net所指定的地址可能需要根据实际情况进行调整。

### 创建TUN设备并建立UDP隧道
服务端
```
gost -L tun://:8421?net=192.168.123.1/24
```
客户端
```
gost -L tun://:8421/SERVER_IP:8421?net=192.168.123.2/24
```
当以上命令运行无误后，可以通过ip addr命令来查看创建的TUN设备：
```
$ ip addr show tun0
2: tun0: <POINTOPOINT,MULTICAST,NOARP,UP,LOWER_UP> mtu 1350 qdisc pfifo_fast state UNKNOWN group default qlen 500
    link/none 
    inet 192.168.123.2/24 scope global tun0
       valid_lft forever preferred_lft forever
    inet6 fe80::d521:ad59:87d0:53e4/64 scope link flags 800 
       valid_lft forever preferred_lft forever
```
可以通过在客户端执行ping命令来测试一下隧道是否连通：
```
$ ping 192.168.123.1
64 bytes from 192.168.123.1: icmp_seq=1 ttl=64 time=9.12 ms
64 bytes from 192.168.123.1: icmp_seq=2 ttl=64 time=10.3 ms
64 bytes from 192.168.123.1: icmp_seq=3 ttl=64 time=7.18 ms
```
如果能ping通，说明隧道已经成功建立。

iperf3测试
服务端
```
$ iperf3 -s
```
客户端
```
$ iperf3 -c 192.168.123.1
```
路由规则和防火墙设置
如果想让客户端访问到服务端的网络，还需要根据需求设置相应的路由和防火墙规则。例如可以将客户端的所有外网流量转发给服务端处理

服务端
开启IP转发并设置防火墙规则
```
$ sysctl -w net.ipv4.ip_forward=1

$ iptables -t nat -A POSTROUTING -s 192.168.123.0/24 ! -o tun0 -j MASQUERADE
$ iptables -A FORWARD -i tun0 ! -o tun0 -j ACCEPT
$ iptables -A FORWARD -o tun0 -j ACCEPT
```
客户端
设置路由规则

> 以下操作会更改客户端的网络环境，除非你知道自己在做什么，请谨慎操作！

```
$ ip route add SERVER_IP/32 dev eth0   # 请根据实际情况替换SERVER_IP和eth0
$ ip route del default   # 删除默认的路由
$ ip route add default via 192.168.123.2  # 使用
```

## TAP
> 目前不支持MacOS。
## 使用说明
```
gost -L="tap://[method:password@][local_ip]:port[/remote_ip:port]?net=192.168.123.2/24&name=tap0&mtu=1350&route=10.100.0.0/16&gw=192.168.123.1"
```
## 基于TCP的TUN/TAP隧道
GOST中的TUN/TAP隧道默认是基于UDP协议进行数据传输。

如果想使用TCP传输，可以选择采用以下几种方式：

### Fake TCP
> Fake TCP不是标准的TCP，只是模拟了TCP协议。
> 此功能仅适用于Linux。

GOST中采用[xtaci/tcpraw](https://github.com/xtaci/tcpraw)内置了对TCP的支持。通过tcp参数开启此功能。

服务端
```
gost -L "tun://:8421?net=192.168.123.1/24&tcp=true"
```
客户端
```
gost -L "tun://:0/SERVER_IP:8421?net=192.168.123.2/24&tcp=true"
```
### 代理链 (2.9.1+)
可以通过使用代理链进行转发，用法与UDP本地端口转发类似。

此方式比较灵活通用，推荐使用。

> 代理链的末端(最后一个-F参数)节点必须支持GOST socks5或ssu协议类型，传输层可以任意选择。
> 使用ssu需要2.10.1+版本。

服务端
```
gost -L tun://:8421?net=192.168.123.1/24" -L socks5://:1080
```
客户端
```
gost -L tun://:0/:8421?net=192.168.123.2/24 -F socks5://SERVER_IP:1080
```
端口转发
利用UDP端口转发配合代理链。

服务端
```
gost -L tun://:8421?net=192.168.123.1/24 -L socks5://:1080
```
客户端
```
gost -L tun://:8421/:8420?net=192.168.123.2/24 -L udp://:8420/:8421 -F socks5://server_ip:1080
```
第三方转发工具
[udp2raw-tunnel](https://github.com/wangyu-/udp2raw-tunnel)。

***

> 转载自https://docs.ginuerzh.xyz/gost/